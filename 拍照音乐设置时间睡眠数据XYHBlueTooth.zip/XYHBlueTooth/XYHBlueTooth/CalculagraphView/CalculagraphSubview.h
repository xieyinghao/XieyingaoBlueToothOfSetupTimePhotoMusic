//
//  CalculagraphSubview.h
//  YB_ Calculagraph
//
//  Created by rimi on 16/3/23.
//  Copyright © 2016年 wakeup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalculagraphSubview : UIView

@property (nonatomic, assign) NSInteger recordIncreaseTimes;
@property (nonatomic, strong) NSMutableArray *imageNames;
@property (nonatomic, strong) UIScrollView *scrollView;

- (instancetype)initWithFrame:(CGRect)frame titleNumberIsTen:(BOOL)isTen;
- (void)increase;
- (void)addTitleToLabel;

@end
