//
//  BaseTextField.m
//  XYZKitDemo
//
//  Created by 谢英泽 on 2016/11/20.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BaseTextField.h"

@implementation BaseTextField

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self initSelf];
}

- (instancetype)init{
    self = [super init];
    if (self) {
        [self initSelf];
    }
    return self;
}

- (void)initSelf
{
    //监听输入
    [self addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
}

- (void)textFieldDidChange:(UITextField *)textField{
    
    if (self.inputBlock) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (textField.text.length > 0) {
                //有输入
                self.inputBlock(YES);
            }else{
                //无输入
                self.inputBlock(NO);
            }
        });
    }
}

@end
