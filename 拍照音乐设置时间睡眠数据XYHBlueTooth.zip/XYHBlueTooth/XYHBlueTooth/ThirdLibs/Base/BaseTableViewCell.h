//
//  BaseTableViewCell.h
//  WTGesturePassword
//
//  Created by wtjr on 16/11/11.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, kTableViewCellLineType) {
    kTableViewCellLineTypeNone,
    kTableViewCellLineTypeNormal,
    kTableViewCellLineTypeAllLine,
};

@interface BaseTableViewCell : UITableViewCell

@property (nonatomic, assign) kTableViewCellLineType tableViewCellLineType;

@end
