//
//  UIView+Rotation.m
//  CustomTabBarController
//
//  Created by wtjr on 16/11/23.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "UIView+Rotation.h"

@implementation UIView (Rotation)

- (void)rotationView:(kRotateType)rotateType isRepeatTime:(id)repeatTime
{
    CABasicAnimation* animation;
    
    if (rotateType == kRotateTypeX) {
        animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    }else if (rotateType == kRotateTypeY){
        animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
    }else{
        animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    }
    
//    animation.repeatCount = HUGE_VALF;
    if (repeatTime == nil) {
        animation.repeatCount = 2;
    }else{
        if ([repeatTime integerValue] == 999) {
            animation.repeatCount = HUGE_VALF;
        }else{
            animation.repeatCount = [repeatTime integerValue];
        }
    }
    
    animation.toValue        = @(M_PI * 1);
    animation.duration       = 0.5;
    animation.cumulative     = YES;
    animation.removedOnCompletion = YES;
    animation.fillMode = kCAFillModeForwards;
    [self.layer addAnimation:animation forKey:@"3D"];
}

@end
