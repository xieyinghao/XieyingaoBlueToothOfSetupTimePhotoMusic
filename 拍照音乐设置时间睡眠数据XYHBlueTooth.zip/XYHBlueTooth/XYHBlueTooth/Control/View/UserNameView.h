//
//  UserNameView.h
//  Fibit
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserNameView : UIView
@property (weak, nonatomic) IBOutlet UITextField *TFname;
@property (weak, nonatomic) IBOutlet UIButton *okButton;
+ (id)initFromXIB;
@end
