//
//  SetUpViewCell.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/12/13.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "SetUpViewCell.h"

@implementation SetUpViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
