//
//  UILabel+Style.m
//  MasonryDemo
//
//  Created by wtjr on 16/11/9.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import "UILabel+Style.h"

@implementation UILabel (Style)

- (void)setLabelStyle:(NSString *)text textColor:(UIColor *)textColor textFont:(UIFont *)textFont texrAlignment:(NSTextAlignment)textAlignment
{
    self.text = text;
    self.textColor = textColor;
    self.font = textFont;
    self.textAlignment = textAlignment;
}

@end
