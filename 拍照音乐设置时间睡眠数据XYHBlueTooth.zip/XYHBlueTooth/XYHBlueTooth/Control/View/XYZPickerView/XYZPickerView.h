//
//  XYZPickerView.h
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppHeader.h"

typedef NS_ENUM(NSInteger,XYZPickerType) {
    XYZPickerTypeTime = 0,
    XYZPickerTypeCutom =1,
};

@class XYZPickerView;

@protocol XYZPickerViewDelegate <NSObject>

- (void)xyzPickerView:(XYZPickerView *)pickerView pickerTime:(NSString *)time;

@end

@interface XYZPickerView : UIView

//每一列的文字颜色
@property (nonatomic, strong)NSArray *arrTinColor;

//每一列的背景颜色
@property (nonatomic, strong)NSArray *arrBgColor;

@property (nonatomic, copy)NSString *defaultDate;

@property (nonatomic, copy) NSString *pickerTitle;

@property (nonatomic, assign)XYZPickerType pickerType;

@property (nonatomic, weak)id<XYZPickerViewDelegate>delegate;

@property (nonatomic, strong)NSArray *dataLists1;
@property (nonatomic, strong)NSArray *dataLists2;
@property (nonatomic, strong)NSArray *dataLists3;

- (instancetype)initWithFrame:(CGRect)frame withType:(XYZPickerType)type titile:(NSString *)title Array1:(NSArray *)arr1 withArray2:(NSArray *)arr2 withArray3:(NSArray *)arr3;

- (void)showPickerView;

- (void)hidePickView;

- (void)reloadPickViewData;

@end
