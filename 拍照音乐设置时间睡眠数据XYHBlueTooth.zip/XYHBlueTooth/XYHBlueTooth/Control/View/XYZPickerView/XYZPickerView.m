//
//  XYZPickerView.m
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//
#define kFONT_system(m)     [UIFont systemFontOfSize:m * 1.1f]
#import "XYZPickerView.h"
#import "XYZPickerCellView.h"
#import "CalculationTime.h"
#import "UILabel+Style.h"
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height

#define kPaddingS  20
#define kPaddingB  30

#define KBtnWidth   60
#define KBtnHeight  24

@interface XYZPickerView ()<XYZPickerCellView>

@property (nonatomic, strong)UIView *viewTop;
@property (nonatomic, strong)UIView *viewPick;

@property (nonatomic, strong)XYZPickerCellView *pickerY;
@property (nonatomic, strong)XYZPickerCellView *pickerM;
@property (nonatomic, strong)XYZPickerCellView *pickerD;

@property (nonatomic, strong)UIButton *btnCancel;
@property (nonatomic, strong)UIButton *btnSure;

@property (nonatomic, copy)NSString *year;
@property (nonatomic, copy)NSString *month;
@property (nonatomic, copy)NSString *day;

@property (nonatomic,strong) UIView *viewMask;

@property (nonatomic, copy)NSString *date;

@property (nonatomic, strong)UIButton *btnBackground;

@end

@implementation XYZPickerView

- (instancetype)initWithFrame:(CGRect)frame withType:(XYZPickerType)type titile:(NSString *)title Array1:(NSArray *)arr1 withArray2:(NSArray *)arr2 withArray3:(NSArray *)arr3
{
    self = [super initWithFrame:frame];
    if (self) {
        _pickerType = type;
        _dataLists1 = arr1;
        _dataLists2 = arr2;
        _dataLists3 = arr3;
        _pickerTitle = title;
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, 270)];
}

- (void)setupUI
{
    CGFloat Width = self.bounds.size.width;
    CGFloat Height = self.bounds.size.height;
    float pickerWidth  = (self.bounds.size.width - 30*4)/3;
    float pickerHeight = (self.bounds.size.height - 44 - kPaddingS);
    
    _viewTop = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Width, 44)];
    _viewTop.backgroundColor = kCOLOR_heavy_blue;
    _viewTop.layer.borderColor = [UIColor colorWithRed:0.9059 green:0.9059 blue:0.9059 alpha:1.0].CGColor;
    _viewTop.layer.borderWidth = 0.3;
    _viewPick = [[UIView alloc] initWithFrame:CGRectMake(kPaddingB, 44, Width - 2*kPaddingB, Height - 44 - kPaddingS)];
    _viewPick.backgroundColor = kCOLOR_white;
    
    [self addSubview:_viewTop];
    [self addSubview:_viewPick];
    
    //确定按钮
    _btnSure = [[UIButton alloc] initWithFrame:CGRectMake(Width - kPaddingS - KBtnWidth, 10, KBtnWidth, KBtnHeight)];
    [_btnSure setTitle:@"确定" forState:UIControlStateNormal];
    _btnSure.titleLabel.font = [UIFont systemFontOfSize:14];
    [_btnSure setTitleColor:kCOLOR_white forState:UIControlStateNormal];
    [_btnSure addTarget:self action:@selector(toSure:) forControlEvents:UIControlEventTouchUpInside];
    [self.viewTop addSubview:_btnSure];
    
    //取消按钮
    _btnCancel = [[UIButton alloc] initWithFrame:CGRectMake(kPaddingS, 10, KBtnWidth, KBtnHeight)];
    [_btnCancel setTitle:@"取消" forState:UIControlStateNormal];
    _btnCancel.titleLabel.font = [UIFont systemFontOfSize:14];
    [_btnCancel setTitleColor:kCOLOR_white forState:UIControlStateNormal];
    [_btnCancel addTarget:self action:@selector(toCancel:) forControlEvents:UIControlEventTouchUpInside];
    [self.viewTop addSubview:_btnCancel];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake((kUI_WIDTH - KBtnWidth-10)/2, 10, KBtnWidth+10, KBtnHeight)];
    [titleLabel setLabelStyle:_pickerTitle textColor:kCOLOR_white textFont:kFONT_system(18.f) texrAlignment:NSTextAlignmentCenter];
    [self.viewTop addSubview:titleLabel];
    
    //日历
    _pickerY = [[XYZPickerCellView alloc] initWithFrame:CGRectMake(0, 0, pickerWidth, pickerHeight)];
    _pickerM = [[XYZPickerCellView alloc] initWithFrame:CGRectMake(kPaddingB + pickerWidth, 0, pickerWidth, pickerHeight)];
    _pickerD = [[XYZPickerCellView alloc] initWithFrame:CGRectMake(kPaddingB*2 + pickerWidth*2, 0, pickerWidth, pickerHeight)];
    
    _pickerY.delegate = self;
    _pickerM.delegate = self;
    _pickerD.delegate = self;
    
    _pickerY.tag = 0;
    _pickerM.tag = 1;
    _pickerD.tag = 2;
    
    [self.viewPick addSubview:_pickerY];
    [self.viewPick addSubview:_pickerM];
    [self.viewPick addSubview:_pickerD];
    
    //中间
    _viewMask = [[UIView alloc] initWithFrame:CGRectMake(0, 134, Width, 30)];
    _viewMask.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.2];
    [self addSubview:_viewMask];
    
    [self initData];
}

- (void)toSure:(UIButton *)btn
{
    [self.delegate xyzPickerView:self pickerTime:_date];
    [self toHide];
}

- (void)toCancel:(UIButton *)btn
{
    [self toHide];
}

- (void)initData
{
    if (_pickerType == XYZPickerTypeCutom)
    {
        _pickerY.dataLists = _dataLists1;
        _pickerM.dataLists = _dataLists2;
        _pickerD.dataLists = _dataLists3;
        
        //今年在数组里的下标
        NSInteger yearIndex = 0;
        //本月在数组里的下标
        NSInteger monthIndex = 0;
        //今天在数组里的下标
        NSInteger dayIndex = 0;
        
        _pickerY.defaultSeleted = yearIndex;
        _pickerM.defaultSeleted = monthIndex;
        _pickerD.defaultSeleted = dayIndex;
    }
    else
    {
        NSDictionary *dictTime;
        
        if (_defaultDate) {
            dictTime = [CalculationTime calculationDefaultTime:_defaultDate];
        }else{
            dictTime = [CalculationTime calculationNowTime];
        }
        
        _year = dictTime[@"year"];
        _month = dictTime[@"month"];
        _day = dictTime[@"day"];
        
        //设置年、月、日、时、分
        _pickerY.dataLists = [CalculationTime calculationYear];
        _pickerM.dataLists = [CalculationTime calculationMonth];
        _pickerD.dataLists = [CalculationTime calculationDay:_year andMonth:_month];
        _date = [NSString stringWithFormat:@"%@-%@-%@",_year,_month,_day];
        
        //今年在数组里的下标
        NSInteger yearIndex = [_year integerValue] - 1900;
        //本月在数组里的下标
        NSInteger monthIndex = [_month integerValue] - 1;
        //今天在数组里的下标
        NSInteger dayIndex = [_day integerValue] - 1;
        
        _pickerY.defaultSeleted = yearIndex;
        _pickerM.defaultSeleted = monthIndex;
        _pickerD.defaultSeleted = dayIndex;
    }
}

//选中的内容和列
- (void)xyzPickerCellView:(XYZPickerCellView *)pickerView choice:(NSString *)content viewTag:(NSUInteger)tag indexRow:(NSInteger)row
{
    if (_pickerType == XYZPickerTypeCutom)
    {
        if(tag == 0){
            _year = content;
            
        }else if(tag == 1){
            
            _month = content;
            
        }else if(tag == 2){
            
            _day = content;
        }
        NSString *time = [NSString stringWithFormat:@"%@-%@-%@",_year,_month,_day];
        _date = time;
    }
    else
    {
        if(tag == 0){
            _year = content;
            if([_month isEqual:@"2"]){
                _pickerD.dataLists = [CalculationTime calculationDay:_year andMonth:_month];
                if(_pickerD.dataLists.count < [_day integerValue]){
                    _day = [NSString stringWithFormat:@"%tu",_pickerD.dataLists.count];
                }
            }
            
        }else if(tag == 1){
            
            _month = content;
            _pickerD.dataLists = [CalculationTime calculationDay:_year andMonth:_month];
            if(_pickerD.dataLists.count < [_day integerValue]){
                _day = [NSString stringWithFormat:@"%tu",_pickerD.dataLists.count];
            }
            
        }else if(tag == 2){
            
            _day = content;
        }
        [self getTime];
    }
    
}

- (void)getTime{
    
    NSString *time = [NSString stringWithFormat:@"%@-%@-%@",_year,_month,_day];
    _date = time;
    
}

- (void)showPickerView
{
    self.btnBackground = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnBackground.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight);
    [self.btnBackground addTarget:self action:@selector(toHide) forControlEvents:UIControlEventTouchUpInside];
    self.btnBackground.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.6];
    self.frame = CGRectMake(0, kScreenHeight, kScreenWidth, 270);
    self.backgroundColor = [UIColor whiteColor];
    [self.btnBackground addSubview:self];
    [[UIApplication sharedApplication].keyWindow addSubview:self.btnBackground];
    
    [UIView animateWithDuration:0.25 animations:^{
        self.frame = CGRectMake(0, kScreenHeight-270, kScreenWidth, 270);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)toHide
{
    [UIView animateWithDuration:0.25 animations:^{
        self.btnBackground.alpha = 0.1;
        self.frame = CGRectMake(0, kScreenHeight, kScreenWidth, 270);
    } completion:^(BOOL finished) {
        [self.btnBackground removeFromSuperview];
        [self removeFromSuperview];
    }];
}
- (void)hidePickView
{
    [self toHide];
}

- (void)reloadPickViewData
{
    self.dataLists1 = nil;
    self.dataLists2 = nil;
    self.dataLists3 = nil;
}

@end
