//
//  XYZPickerCellView.m
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "XYZPickerCellView.h"
#import "XYZPickerCell.h"

@implementation XYZPickerCellView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    self.tableView.frame = self.bounds;
}

- (void)setupUI
{
    _tableView = [[UITableView alloc] initWithFrame:self.bounds];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.showsHorizontalScrollIndicator = NO;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.bounces = NO;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.rowHeight = 30;
    [self addSubview:_tableView];
    
    //设置tableview分割线长度(ios7/ios8)
    if ([_tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [_tableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    if ([_tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [_tableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

#pragma mark - Delegate

#pragma mark - UITableViewDataSource

//返回行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataLists.count + 6;
}

//返回Cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseIdetify = @"XYZPickerCell";
    XYZPickerCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdetify];
    if (cell ==nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:reuseIdetify owner:self options:nil] lastObject];
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
    }
    
    if(_tinColor){
        cell.lbText.textColor = _tinColor;
    }
    
    //如果是前三行或者最后3行则没有内容
    if(indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2 || indexPath.row == _dataLists.count+3 || indexPath.row == _dataLists.count+4 || indexPath.row == _dataLists.count+5){
        cell.lbText.text = @"";
    }else{
        if(self.tag == 2 && [_dataLists[indexPath.row-3] isKindOfClass:[NSDictionary class]]){
            NSDictionary *dict = _dataLists[indexPath.row-3];
            cell.lbText.text = [NSString stringWithFormat:@"%@",dict[@"day"]];
        }
        if(self.tag == 0){
            cell.lbText.text = [NSString stringWithFormat:@"%@",_dataLists[indexPath.row-3]];
        }else if(self.tag == 1){
            cell.lbText.text = [NSString stringWithFormat:@"%@",_dataLists[indexPath.row-3]];
        }else{
            cell.lbText.text = [NSString stringWithFormat:@"%@",_dataLists[indexPath.row-3]];
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2 || indexPath.row == _dataLists.count+3 || indexPath.row == _dataLists.count+4 || indexPath.row == _dataLists.count+5){
        return;
    }
    
    NSString *content;
    if(self.tag == 2 && [_dataLists[indexPath.row-3] isKindOfClass:[NSDictionary class]]){
        NSDictionary *dict = _dataLists[indexPath.row-3];
        content = dict[@"day"];
    }else{
        content = _dataLists[indexPath.row-3];
    }
    
    NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:indexPath.row-3 inSection:0];
    [_tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    [_delegate xyzPickerCellView:self choice:content viewTag:self.tag indexRow:indexPath.row-3];
}

//手指一直按着滑动停止
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self updateScrollViewContentOffset:scrollView];
}

//手指松开滚动停止
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self updateScrollViewContentOffset:scrollView];
}

//计算中间的cell，并返回值
- (void)updateScrollViewContentOffset:(UIScrollView *)scrollView{

    
    CGPoint point = scrollView.contentOffset;
    
    float m = (NSInteger)point.y % 30;
    
    if(m > 0 && m <= 15){
        
        scrollView.contentOffset = CGPointMake(point.x, point.y-m);
        
    }else if (m > 15 && m < 30){
        
        scrollView.contentOffset = CGPointMake(point.x, point.y+30-m);
        
    }
    
    CGPoint point1 = scrollView.contentOffset;
    NSInteger s = point1.y / 30;
    NSInteger f = s;
    
    NSString *content;
    if(self.tag == 2 && [_dataLists[f] isKindOfClass:[NSDictionary class]]){
        NSDictionary *dict = _dataLists[f];
        content = dict[@"day"];
    }else{
        content = _dataLists[f];
    }
    [_delegate xyzPickerCellView:self choice:content viewTag:self.tag indexRow:f];
}

#pragma mark - Getter && Setter

- (void)setDataLists:(NSArray *)dataLists
{
    _dataLists = dataLists;
    [_tableView reloadData];
}

- (void)setDefaultSeleted:(NSInteger)defaultSeleted
{
    NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:defaultSeleted inSection:0];
    [_tableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)setTinColor:(UIColor *)tinColor
{
    _tinColor = tinColor;
    [_tableView reloadData];
}

@end
