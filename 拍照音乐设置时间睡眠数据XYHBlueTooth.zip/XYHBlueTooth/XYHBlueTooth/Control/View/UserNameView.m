//
//  UserNameView.m
//  Fibit
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import "UserNameView.h"

@implementation UserNameView

+ (id)initFromXIB
{
    NSArray* xibs = [[NSBundle mainBundle]loadNibNamed:@"UserNameView" owner:self options:nil];
    
    return xibs[0];
}

@end
