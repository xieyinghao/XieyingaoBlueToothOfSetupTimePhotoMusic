//
//  NSData+TSExtension.m
//  37duc
//
//  Created by Ray on 16/2/24.
//  Copyright © 2016年 37service. All rights reserved.
//

#import "NSData+TSExtension.h"

@implementation NSData (TSExtension)

- (NSString *)ConvertToNSString {
    NSMutableString *strTemp = [NSMutableString stringWithCapacity:[self length]*2];
    
    const unsigned char *szBuffer = [self bytes];
    for (NSInteger i=0; i < [self length]; ++i) {
        [strTemp appendFormat:@"%02lx",(unsigned long)szBuffer[i]];
    }
    return strTemp;
}

@end
