//
//  SleepResultNotifyView.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SleepResultNotifyView : UIView
@property (weak, nonatomic) IBOutlet UISwitch *sleepSwith;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UIButton *okButton;
+ (id)initFromXIB;
@end
