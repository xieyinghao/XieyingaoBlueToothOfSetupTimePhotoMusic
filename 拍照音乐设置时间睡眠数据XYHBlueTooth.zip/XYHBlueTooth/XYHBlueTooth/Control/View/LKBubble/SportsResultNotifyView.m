//
//  SportsResultNotifyView.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "SportsResultNotifyView.h"

@implementation SportsResultNotifyView

+ (id)initFromXIB
{
    NSArray* xibs = [[NSBundle mainBundle]loadNibNamed:@"SportsResultNotifyView" owner:self options:nil];
    
    return xibs[0];
}

@end
