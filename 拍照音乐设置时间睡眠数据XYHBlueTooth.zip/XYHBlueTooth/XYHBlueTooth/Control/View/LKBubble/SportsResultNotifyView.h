//
//  SportsResultNotifyView.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SportsResultNotifyView : UIView
@property (weak, nonatomic) IBOutlet UIButton *okbutton;
@property (weak, nonatomic) IBOutlet UISwitch *sportSwith;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
+ (id)initFromXIB;
@end
