//
//  SetUpViewCell.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/12/13.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetUpViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *timeLable;

@end
