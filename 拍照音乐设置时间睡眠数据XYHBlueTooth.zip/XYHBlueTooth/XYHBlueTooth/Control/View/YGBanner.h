//
//  YGBanner.h
//  
//
//  Created by wuyiguang on 16/4/27.
//
//

#import <UIKit/UIKit.h>

@interface YGBanner : UIView

/**
 *  创建轮播图
 *
 *  @param frame  轮播图的frame
 *  @param names  轮播显示的图片
 *  @param handle 图片点击的回调，传回一个图片的名称
 *
 *  @return 返回YGBanner实例
 */
- (instancetype)initWithFrame:(CGRect)frame imageNames:(NSArray *)names imageHandle:(void(^)(NSString *title))handle;

@end
