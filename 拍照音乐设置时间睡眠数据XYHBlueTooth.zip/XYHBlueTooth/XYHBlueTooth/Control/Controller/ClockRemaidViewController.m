//
//  ClockRemaidViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "ClockRemaidViewController.h"
#import "GUAAlertView.h"
@interface ClockRemaidViewController ()

@end

@implementation ClockRemaidViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
}
#pragma mark - *********************基础方法*********************
-(void)initUI
{
    self.title = @"闹钟提醒";
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    self.view.backgroundColor = [UIColor whiteColor];
    //上部分视图
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, ScreenH*0.5)];
    bgView.backgroundColor = [UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1];
    [self.view addSubview:bgView];
    
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgView.frame.size.height*0.5-50, ScreenW/5,  ScreenW/5)];
    image1.image = [UIImage imageNamed:@"智能手环"];
    [bgView addSubview:image1];
    
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake( ScreenW/5, bgView.frame.size.height*0.5-50, ScreenW/5,   ScreenW/5)];
    image2.image = [UIImage imageNamed:@"点-2"];
    [bgView addSubview:image2];
    
    UIImageView *image3 = [[UIImageView alloc]initWithFrame:CGRectMake( ScreenW/5+ScreenW/5, bgView.frame.size.height*0.5-50, ScreenW/5,   ScreenW/5)];
    image3.image = [UIImage imageNamed:@"手机"];
    [bgView addSubview:image3];
    
    UIImageView *image4 = [[UIImageView alloc]initWithFrame:CGRectMake( ScreenW/5+ScreenW/5+ScreenW/5, bgView.frame.size.height*0.5-50, ScreenW/5,   ScreenW/5)];
    image4.image = [UIImage imageNamed:@"点"];
    [bgView addSubview:image4];
    
    UIImageView *image5 = [[UIImageView alloc]initWithFrame:CGRectMake(  ScreenW/5+ScreenW/5+ScreenW/5+ScreenW/5, bgView.frame.size.height*0.5-50, ScreenW/5,   ScreenW/5)];
    image5.image = [UIImage imageNamed:@"clock"];
    [bgView addSubview:image5];
    
    UILabel *titleLable =[[ UILabel alloc]initWithFrame:CGRectMake(0, ScreenH*0.5-30, ScreenW, 30)];
    titleLable.text = @"手机需一直连接手环，请保持蓝牙开启";
    titleLable.textColor = [UIColor whiteColor];
    titleLable.textAlignment = NSTextAlignmentCenter;
    titleLable.font = [UIFont systemFontOfSize:15];
    [bgView addSubview:titleLable];
    
    //下部分UI控件
    UILabel *massageLable = [[UILabel alloc]initWithFrame:CGRectMake(15, ScreenH*0.5, 100, 30)];
    massageLable.text = @"开启来电提醒";
    massageLable.textColor = [UIColor grayColor];
    massageLable.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:massageLable];
    
    UISwitch *swith = [[UISwitch alloc]initWithFrame:CGRectMake(ScreenW-60,ScreenH*0.5+5 , 30, 30)];
    //    // 开时的颜色
    swith.onTintColor = [UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1];
    [self.view addSubview:swith];
    
    [swith addTarget:self action:@selector(switchHandle:) forControlEvents:UIControlEventValueChanged];
}
#pragma mark - *********************代理方法*********************
- (void)switchHandle:(UISwitch *)swch
{
//    if (swch.on) {
//        self.view.backgroundColor = [UIColor whiteColor];
//    } else {
//        self.view.backgroundColor = [UIColor grayColor];
//    }
    GUAAlertView *v = [GUAAlertView alertViewWithTitle:@"温馨提示"
                                               message:@"蓝牙尚未连接"
                                           buttonTitle:@"知道了！"
                                   buttonTouchedAction:^{
                                       NSLog(@"button touched");
                                   } dismissAction:^{
                                       NSLog(@"dismiss");
                                   }];
    [v show];
}
#pragma mark - *********************响应事件*********************


#pragma mark - *********************懒加载*********************


#pragma mark - *********************网络模型*********************

@end
