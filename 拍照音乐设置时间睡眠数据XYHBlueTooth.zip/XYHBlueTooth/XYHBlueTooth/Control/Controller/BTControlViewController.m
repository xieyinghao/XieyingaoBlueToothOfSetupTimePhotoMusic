//
//  ControlViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "BTControlViewController.h"
#import "TSSquareButton.h"
#import "GUAAlertView.h"
#import "ClockRemaidViewController.h"
#import "LeafNotification.h"
#import "BlueToothManager.h"
#import "XYHUIImagePickerController.h"
//音乐播放
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
@interface BTControlViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *buttons;
@property(nonatomic,strong)NSMutableArray *images;
@property(nonatomic,strong)UIView *crowdfundingView;
@property(nonatomic,strong)UILabel *statelable1;
@property(nonatomic,strong)UILabel *statelable2;
@property(nonatomic,strong)UILabel *statelable4;
@property(nonatomic,strong)UILabel *statelable5;
@property(nonatomic,strong)UILabel *statelable6;

@property (strong, nonatomic) MPMusicPlayerController *musicPlayerController; //音乐播放器
@property (assign, nonatomic) MPMusicPlaybackState musicPlaybackState; //播放状态
@property (strong, nonatomic) MPMediaQuery *query; //媒体队列
@end

@implementation BTControlViewController

#pragma mark - *********************生命周期*********************

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configuration];
    
    [self autoLayoutForSubView];
    
    //初始化
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    
    //扫描
    [manager scan];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeValue) name:@"zipai" object:nil];
    
    //音乐播放
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setActive:YES error:nil];
    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
    //    说明：播放内置媒体库项目取代用户目前播放状态（如果是用网易云音乐或QQQ音乐在播放歌曲）
    self.musicPlayerController = [MPMusicPlayerController applicationMusicPlayer];
    //    self.musicPlayerController = [MPMusicPlayerController systemMusicPlayer];//初始化系统音乐播放器
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(systemMusicPlayerControl:) name:@"musicPlay" object:nil];


}
#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
    CBPeripheral *peripheral = peripherals.firstObject;
    //过滤外设，当前缀为SMART的外设才进行连接
    //    if ([peripheral.name hasPrefix:@"SMART"]) {
    //
    //        //连接外部设备
    //        [weakManager connect:peripheral];
    //        NSLog(@"连接成功");
    //    }
    [weakManager connect:peripheral];
    
    
}
#pragma mark - *********************基础配置*********************

- (void)configuration
{
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] objectForKey:@"CallRemaid"];
    [self setTitle:@"控制"];
    [self hideNaviBack];
    [self resetNavBackItemTinColor:kCOLOR_white];
    
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,0, ScreenW, ScreenH)];
    self.tableView.delegate  =self;
    self.tableView.dataSource = self;
    
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 0,ScreenW , 0.5)];
    line.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    self.tableView.tableFooterView = line;
    
    self.crowdfundingView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW,161.5)];
    self.crowdfundingView.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [self.view addSubview:self.crowdfundingView];
    UIView *headline = [[UIView alloc]initWithFrame:CGRectMake(0, 0,ScreenW , 0.5)];
    headline.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [self.crowdfundingView addSubview:headline];
    
    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(0, 0.5, ScreenW/2, 80)];
    btn1.backgroundColor = [UIColor whiteColor];
    [self.crowdfundingView addSubview:btn1];
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(btn1.frame.size.width/2-12.5, 10, 35, 35)];
    image1.image = [UIImage imageNamed:@"calling"];
    [btn1 addSubview:image1];
    UILabel *titlelable1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn1.frame.size.width, 15)];
    titlelable1.text = @"来电提醒";
    titlelable1.textColor =[UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    titlelable1.font = [UIFont systemFontOfSize:14];
    titlelable1.textAlignment = NSTextAlignmentCenter;
    [btn1 addSubview:titlelable1];
    self.statelable1 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn1.frame.size.width, 15)];
     self.statelable1.text = @"未开启";
//    NSMutableDictionary *dictM = [[NSMutableDictionary alloc] init];
//    [dictM setObject: @"未开启" forKey:@"statelable1"];
//    [[NSUserDefaults standardUserDefaults] setObject:dictM forKey:@"account1"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
    self.statelable1.font = [UIFont systemFontOfSize:10];
    self.statelable1.textColor = [UIColor grayColor];
    self.statelable1.textAlignment = NSTextAlignmentCenter;
    [btn1 addSubview:self.statelable1];
    [btn1 addTarget:self action:@selector(editingState1) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *btn2 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenW/2+1, 0.5, ScreenW/2, 80)];
    btn2.backgroundColor = [UIColor whiteColor];
    [self.crowdfundingView addSubview:btn2];
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(btn2.frame.size.width/2-12.5, 10, 35, 35)];
    image2.image = [UIImage imageNamed:@"clock"];
    [btn2 addSubview:image2];
    UILabel *titlelable2 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn2.frame.size.width, 15)];
    titlelable2.text = @"手环闹钟";
    titlelable2.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    titlelable2.font = [UIFont systemFontOfSize:14];
    titlelable2.textAlignment = NSTextAlignmentCenter;
    [btn2 addSubview:titlelable2];
    self.statelable2 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn2.frame.size.width, 15)];
     self.statelable2.text = @"未开启";
     self.statelable2.font = [UIFont systemFontOfSize:10];
     self.statelable2.textColor = [UIColor grayColor];
     self.statelable2.textAlignment = NSTextAlignmentCenter;
    [btn2 addSubview: self.statelable2];
    [btn2 addTarget:self action:@selector(editingState2) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn3 = [[UIButton alloc]initWithFrame:CGRectMake(0, 81, ScreenW/2, 80)];
    btn3.backgroundColor = [UIColor whiteColor];
    [self.crowdfundingView addSubview:btn3];
    UIImageView *image3 = [[UIImageView alloc]initWithFrame:CGRectMake(btn2.frame.size.width/2-12.5, 10, 35, 35)];
    image3.image = [UIImage imageNamed:@"fuwu"];
    [btn3 addSubview:image3];
    UILabel *titlelable3 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn2.frame.size.width, 15)];
    titlelable3.text = @"开启ANCS";
    titlelable3.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    titlelable3.font = [UIFont systemFontOfSize:14];
    titlelable3.textAlignment = NSTextAlignmentCenter;
    [btn3 addSubview:titlelable3];
    UILabel *statelable3 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn2.frame.size.width, 15)];
    statelable3.text = @"已开启";
    statelable3.font = [UIFont systemFontOfSize:10];
    statelable3.textColor = [UIColor grayColor];
    statelable3.textAlignment = NSTextAlignmentCenter;
    [btn3 addSubview:statelable3];
    [btn3 addTarget:self action:@selector(editingState3) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn4 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenW/2+1, 81, ScreenW/2, 80)];
    btn4.backgroundColor = [UIColor whiteColor];
    [self.crowdfundingView addSubview:btn4];
    UIImageView *image4 = [[UIImageView alloc]initWithFrame:CGRectMake(btn2.frame.size.width/2-12.5, 10, 35, 35)];
    image4.image = [UIImage imageNamed:@"message"];
    [btn4 addSubview:image4];
    UILabel *titlelable4 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn2.frame.size.width, 15)];
    titlelable4.text = @"短信提醒";
    titlelable4.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    titlelable4.font = [UIFont systemFontOfSize:14];
    titlelable4.textAlignment = NSTextAlignmentCenter;
    [btn4 addSubview:titlelable4];
    self.statelable4 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn2.frame.size.width, 15)];
     self.statelable4.text = @"未开启";
     self.statelable4.font = [UIFont systemFontOfSize:10];
     self.statelable4.textColor = [UIColor grayColor];
     self.statelable4.textAlignment = NSTextAlignmentCenter;
    [btn4 addSubview: self.statelable4];
    [btn4 addTarget:self action:@selector(editingState4) forControlEvents:UIControlEventTouchUpInside];
    
    
//    UIButton *btn5 = [[UIButton alloc]initWithFrame:CGRectMake(0, 162, ScreenW/2, 80)];
//    btn5.backgroundColor = [UIColor whiteColor];
//    [self.crowdfundingView addSubview:btn5];
//    UIImageView *image5 = [[UIImageView alloc]initWithFrame:CGRectMake(btn2.frame.size.width/2-12.5, 10, 35, 35)];
//    image5.image = [UIImage imageNamed:@"music"];
//    [btn5 addSubview:image5];
//    UILabel *titlelable5 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn2.frame.size.width, 15)];
//    titlelable5.text = @"控制音乐";
//    titlelable5.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
//    titlelable5.font = [UIFont systemFontOfSize:14];
//    titlelable5.textAlignment = NSTextAlignmentCenter;
//    [btn5 addSubview:titlelable5];
//   self.statelable5 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn2.frame.size.width, 15)];
//    self.statelable5.text = @"未开启";
//    self.statelable5.font = [UIFont systemFontOfSize:10];
//    self.statelable5.textColor = [UIColor grayColor];
//    self.statelable5.textAlignment = NSTextAlignmentCenter;
//    [btn5 addSubview:self.statelable5];
//    [btn5 addTarget:self action:@selector(editingState5) forControlEvents:UIControlEventTouchUpInside];
//    
//    UIButton *btn6 = [[UIButton alloc]initWithFrame:CGRectMake(ScreenW/2+1, 162, ScreenW/2, 80)];
//    btn6.backgroundColor = [UIColor whiteColor];
//    [self.crowdfundingView addSubview:btn6];
//    UIImageView *image6 = [[UIImageView alloc]initWithFrame:CGRectMake(btn2.frame.size.width/2-12.5, 10, 35, 35)];
//    image6.image = [UIImage imageNamed:@"picture"];
//    [btn6 addSubview:image6];
//    UILabel *titlelable6 = [[UILabel alloc]initWithFrame:CGRectMake(0, 45, btn2.frame.size.width, 15)];
//    titlelable6.text = @"控制拍照";
//    titlelable6.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
//    titlelable6.font = [UIFont systemFontOfSize:14];
//    titlelable6.textAlignment = NSTextAlignmentCenter;
//    [btn6 addSubview:titlelable6];
//    self.statelable6 = [[UILabel alloc]initWithFrame:CGRectMake(0,60, btn2.frame.size.width, 15)];
//    self.statelable6.text = @"未开启";
//    self.statelable6.font = [UIFont systemFontOfSize:10];
//    self.statelable6.textColor = [UIColor grayColor];
//    self.statelable6.textAlignment = NSTextAlignmentCenter;
//    [btn6 addSubview:self.statelable6];
//    [btn6 addTarget:self action:@selector(editingState6) forControlEvents:UIControlEventTouchUpInside];
    
    
    self.tableView.tableHeaderView = self.crowdfundingView;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.view addSubview:self.tableView];


}

- (void)autoLayoutForSubView
{
    
}

#pragma mark - *********************基础方法*********************


#pragma mark - *********************代理方法*********************
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 44)];
    UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, ScreenW, 44)];
    lable.text = @"   第三方接入";
    lable.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    lable.font = [UIFont systemFontOfSize:12];
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 43.5, ScreenW, 0.5)];
    line.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [view addSubview:line];
    [view addSubview:lable];
    return view;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    if (indexPath.row == 1) {
        cell.textLabel.text = @"微信";
        cell.imageView.image = [UIImage imageNamed:@"微信"];
        
    }else
    {
        cell.textLabel.text = @"QQ";
        cell.imageView.image = [UIImage imageNamed:@"QQ"];
        
    }
    cell.accessoryType= UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
//    GUAAlertView *v = [GUAAlertView alertViewWithTitle:@"温馨提示"
//                                               message:@"该功能暂未开放"
//                                           buttonTitle:@"知道了！"
//                                   buttonTouchedAction:^{
//                                       NSLog(@"button touched");
//                                   } dismissAction:^{
//                                       NSLog(@"dismiss");
//                                   }];
//    [v show];
    
     [LeafNotification showInController:self withText:@"该功能暂未开放!" type:LeafNotificationTypeWarrning];
    
    
}

#pragma mark - *********************响应事件*********************
//来电提醒
-(void)editingState1
{
    [LeafNotification showInController:self withText:@"来电不可设置!" type:LeafNotificationTypeWarrning];

}
//手环闹钟
-(void)editingState2
{
    ClockRemaidViewController *vc = [[ClockRemaidViewController alloc]init];
    vc.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:vc animated:YES];
}
//app通知
-(void)editingState3
{
    [LeafNotification showInController:self withText:@"已经开启!" type:LeafNotificationTypeSuccess];
     NSString *uuid = @"FFF2";
    // 控制手环ANCS
    Byte byte1[4];
    byte1[0] = 0xA1;
    byte1[1] = 0x01;
    byte1[2] = 0x01;//kaiqi
    byte1[3] = byte1[2];
    NSData *data1 = [NSData dataWithBytes:byte1 length:4];
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data1 characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    
}
//短信通知
-(void)editingState4
{
     [LeafNotification showInController:self withText:@"短信提醒不可设置!" type:LeafNotificationTypeWarrning];

}


#pragma mark - *********************懒加载*********************


#pragma mark - *********************网络模型*********************
#pragma =====================音乐播放=====================================
- (void)systemMusicPlayerControl:(NSNotification *)notification {
    //音乐播放 <f60102> 上一首  <f60103>下一首  <f60101>暂停与播放
    NSData *data = notification.object;  //蓝牙设备传来的控制信息
    Byte *bytes = (Byte *)[data bytes];
    self.musicPlaybackState = self.musicPlayerController.playbackState;
    if (bytes[1] == 0x01) {  //验证
        if (![self isPlayingItem]) {
            [self createMediaQuery];  //若没有正在播放的媒体项目，则创建媒体队列
        }
        if (bytes[2] == 0x01) { // 播放/停止
            
            if (self.musicPlaybackState == MPMusicPlaybackStatePlaying) {
                [self.musicPlayerController pause]; //暂停
                NSLog(@"暂停Music Control Error Data!");
            }
            if (self.musicPlaybackState == MPMusicPlaybackStateStopped || self.musicPlaybackState == MPMusicPlaybackStatePaused || self.musicPlaybackState == MPMusicPlaybackStateInterrupted) {
                [self.musicPlayerController play]; //播放
                NSLog(@"播放Music Control Error Data!");
            }
        } else if (bytes[2] == 0x02) { // 切换上一曲
            [self.musicPlayerController skipToPreviousItem];
            NSLog(@"切换上一曲Music Control Error Data!");
        } else if (bytes[2] == 0x03) { // 切换下一曲
            [self.musicPlayerController skipToNextItem];
            NSLog(@"切换下一曲Music Control Error Data!");
        } else {
            NSLog(@"Music Control Error Data!");
        }
    }
}
// 判断有没有正在播放的媒体项目
- (BOOL)isPlayingItem {
    if ([self.musicPlayerController indexOfNowPlayingItem] == NSNotFound) {
        return NO;
    } else {
        return YES;
    }
}
//创建媒体队列
- (void)createMediaQuery {
    self.query = [MPMediaQuery songsQuery];
    [self.musicPlayerController setQueueWithQuery:self.query];
}
#pragma =====================音乐播放=====================================
-(void)changeValue
{
    
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    //    {
    //        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;//设置类型为相机
    //        UIImagePickerController *picker = [[UIImagePickerController alloc] init];//初始化
    //        picker.delegate = self;//设置代理
    //        picker.allowsEditing = YES;//设置照片可编辑
    //        picker.sourceType = sourceType;
    //        //设置是否显示相机控制按钮 默认为YES
    //        picker.showsCameraControls = YES;
    //
    //        //        //创建叠加层(例如添加的相框)
    //        //        UIView *overLayView=[[UIView alloc]initWithFrame:CGRectMake(0, 120, 320, 254)];
    //        //        //取景器的背景图片，该图片中间挖掉了一块变成透明，用来显示摄像头获取的图片；
    //        //        UIImage *overLayImag=[UIImage imageNamed:@"zhaoxiangdingwei.png"];
    //        //        UIImageView *bgImageView=[[UIImageView alloc]initWithImage:overLayImag];
    //        //        [overLayView addSubview:bgImageView];
    //        //        picker.cameraOverlayView=overLayView;
    //
    //        //选择前置摄像头或后置摄像头
    //        picker.cameraDevice=UIImagePickerControllerCameraDeviceFront;
    //        [self presentViewController:picker animated:YES completion:^{
    //        }];
    //    }
    //    else {
    //        NSLog(@"该设备无相机");
    //    }
    
    XYHUIImagePickerController *vc = [[XYHUIImagePickerController alloc]init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
    
}
@end
