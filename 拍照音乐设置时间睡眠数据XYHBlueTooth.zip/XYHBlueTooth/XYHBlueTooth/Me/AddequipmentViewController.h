//
//  AddequipmentViewController.h
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddequipmentMassage.h"
#import <CoreBluetooth/CoreBluetooth.h>
// 1. 声明一个Block
typedef void(^CallBack)(AddequipmentMassage *user);
@interface AddequipmentViewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>
{
    CBCentralManager *theManager;
    CBPeripheral *thePerpher;
    CBCharacteristic *theSakeCC;
}
// 2. 声明一个属性
@property (nonatomic, copy) CallBack block;
@end
