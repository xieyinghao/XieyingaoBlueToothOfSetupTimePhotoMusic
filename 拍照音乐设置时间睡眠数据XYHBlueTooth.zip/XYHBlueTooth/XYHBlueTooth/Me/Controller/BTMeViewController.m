//
//  MeViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "BTMeViewController.h"
#import "UIImage+Color.h"
#import "UserMassageViewController.h"
#import "YHAccountViewViewCell.h"
#import "AccountHeadView.h"
#import "AddequipmentCell.h"
#import "AddequipmentViewController.h"
#import "SetUpViewController.h"
#import "SSPopup.h"
#import "XMRTimePiker.h"
#import "SportsResultNotifyView.h"
#import "SleepResultNotifyView.h"
#import "AddequipmentMassage.h"
#import "UnityTool.h"
#import "UIView+Shake.h"
#import "UIView+HeartBeat.h"
#import "UIView+Rotation.h"
@interface BTMeViewController ()<UITableViewDelegate,UITableViewDataSource,UIPickerViewDataSource , UIPickerViewDelegate,XMRTimePikerDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *headView;
//* 用户头像按钮
@property (weak, nonatomic)  UIButton *userImageButton;
@property(nonatomic,strong)NSArray *titleArr;
@property(nonatomic,strong)NSArray *mytitleArr;

@property(nonatomic,strong)NSString *exerciseTargetStr;
@property(nonatomic,strong)NSString *sleepTargetStr;
@property(nonatomic,strong)SportsResultNotifyView  *addView;
@property(nonatomic,strong)SleepResultNotifyView *sleepview;
@property(nonatomic,strong) UIView *cellbgview;
@property(nonatomic,strong)NSString *NameStr;
@property(nonatomic,strong)NSString *MacStr;
@property(nonatomic)BOOL isLock;
@end

@implementation BTMeViewController

#pragma mark - *********************生命周期*********************
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [UnityTool shareInstance];
    [self.tableView reloadData];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //设置导航栏颜色
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:kCOLOR_tabBar] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    
    //开启系统侧滑
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    [self configuration];
    
    [self autoLayoutForSubView];
    
}

#pragma mark - *********************基础配置*********************

- (void)configuration
{
    [self setTitle:@"我的"];
    
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, ScreenH-64) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 54;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"tableviewcell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AddequipmentCell" bundle:nil] forCellReuseIdentifier:@"AddequipmentCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"YHAccountViewViewCell" bundle:nil] forCellReuseIdentifier:@"YHAccountViewViewCell"];
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 1)];
    view.backgroundColor = [UIColor whiteColor];
    self.tableView.tableFooterView = view;
    
    AccountHeadView *headview = [AccountHeadView initFromXIB];
    CGRect bounds = headview.bounds;
    bounds.size.width = ScreenW ;
    bounds.size.height = 250;
    headview.bounds = bounds;
    self.tableView.tableHeaderView = headview;
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 249.5, ScreenW, 0.5)];
    view1.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [headview addSubview:view1];
    [headview.userButton addTarget:self action:@selector(editMassage) forControlEvents:UIControlEventTouchUpInside];
    headview.headIcon.image = [UIImage imageNamed:@"头像大"];
    //抖动效果
//        [headview.headIcon shakeWithOptions:SCShakeOptionsDirectionHorizontal | SCShakeOptionsForceInterpolationNone | SCShakeOptionsAtEndContinue force:0.1 duration:10 iterationDuration:0.3 completionHandler:nil];
    // 设置圆角
    headview.headIcon.layer.cornerRadius = 40;
    
    // 允许切圆
    headview.headIcon.layer.masksToBounds = YES;
    
    // 设置外框的颜色
    headview.headIcon.layer.borderColor = [UIColor whiteColor].CGColor;
    
    // 设置外框的颜色的厚度
    headview.headIcon.layer.borderWidth = 2.0;
    headview.nameLable.text = [UnityTool  getStringValueForConfigurationKey:kUSER_Name];
    
}

- (void)autoLayoutForSubView
{
    
}

#pragma mark - *********************基础方法*********************

//设置个人信息
-(void)editMassage
{
    UserMassageViewController *vc = [[UserMassageViewController alloc]init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - *********************代理方法*********************
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else if (section == 1)
    {
        return 2;
    }else
    {
        return 2;
    }
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 44)];
    
    NSArray *array = @[@"我的设备",@"目标设置",@"状态提醒",@"更多"];
    UILabel *titleLable = [[UILabel alloc]initWithFrame:CGRectMake(15, 0,ScreenW , 44)];
    titleLable.text = array[section];
    titleLable.textColor = [[UIColor blackColor]colorWithAlphaComponent:0.3];
    titleLable.font = [UIFont systemFontOfSize:15];
    [view addSubview:titleLable];
    return view;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YHAccountViewViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YHAccountViewViewCell"];
     [cell.icon heartBeat:@999];
    if (indexPath.section == 0) {
        if ([UnityTool getBoolValueForConfigurationKey:@"bangding"] == NO) {
            
            AddequipmentCell *addcell = [tableView dequeueReusableCellWithIdentifier:@"AddequipmentCell"];
            [addcell.AddequipmentButton addTarget:self action:@selector(gotoAddequipmentViewController) forControlEvents:UIControlEventTouchUpInside];
            return addcell;
        }else{
            
            YHAccountViewViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:@"YHAccountViewViewCell"];
            cell1.icon.image = [UIImage imageNamed:@"智能手环"];
             [ cell1.icon rotationView:kRotateTypeY isRepeatTime:@999];
            cell1.typeLable.text = [NSString stringWithFormat:@"%@:%@",[UnityTool getStringValueForConfigurationKey:@"bangdingName"],[UnityTool getStringValueForConfigurationKey:@"bangdingID"]];
            cell1.textLble.text = @"已绑定";
            return cell1;
            
        }
        
    }
    if (indexPath.section == 1) {
        NSArray *imag = @[@"橙色计划-icon_运动",@"图标_睡眠"];
        cell.icon.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",imag[indexPath.row]]];
        NSArray *arry = @[@"运动目标",@"睡眠设置"];
        NSArray *titleArry = @[[UnityTool getStringValueForConfigurationKey:@"sport"],[UnityTool getStringValueForConfigurationKey:@"time"]];
        cell.typeLable.text = arry[indexPath.row];
        cell.textLble.text = titleArry[indexPath.row];
    }if (indexPath.section == 2) {
        NSArray *imag = @[@"成绩",@"熟睡"];
        cell.icon.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",imag[indexPath.row]]];
        NSArray *arry = @[@"运动成绩提醒",@"睡眠结果提醒"];
         NSArray *titleArry = @[[UnityTool getStringValueForConfigurationKey:@"sporttips"],[UnityTool getStringValueForConfigurationKey:@"sleeptips"]];
        cell.typeLable.text = arry[indexPath.row];
        cell.textLble.text = titleArry[indexPath.row];
    }
    if (indexPath.section == 3) {
        
        NSArray *imag = @[@"设置",@"意见反馈"];
        cell.icon.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",imag[indexPath.row]]];
        NSArray *arry = @[@"设置",@"意见反馈"];
        cell.typeLable.text = arry[indexPath.row];
        cell.textLble.text = @"";
    }
    if (indexPath.section == 0) {
        cell.backgroundColor = [[UIColor orangeColor]colorWithAlphaComponent:0.4];
    }
    return cell;
    
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        
        UIActionSheet* actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:@"请确定以下操作"
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:nil
                                      otherButtonTitles:@"解绑",nil];
        [actionSheet showInView:self.view];
        
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            NSArray *QArray=[[NSArray alloc]initWithObjects:@"1000",@"2000",@"3000",@"4000",@"5000",@"6000",@"7000",@"8000",@"9000", nil];
            
            SSPopup* selection=[[SSPopup alloc]init];
            selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
            
            selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
            selection.SSPopupDelegate=self;
            [self.view  addSubview:selection];
            
            [selection CreateTableview:QArray withSender:self.tableView  withTitle:@"运动目标" setCompletionBlock:^(int tag){
                
                NSLog(@"Tag--->%d",tag);
                [UnityTool shareInstance];
                [UnityTool setStringValueForConfigurationKey:@"sport" WithValue:[NSString stringWithFormat:@"%ld",(tag+1)*1000]];
//                self.exerciseTargetStr = [NSString stringWithFormat:@"%ld",(tag+1)*10];
                [self.tableView reloadData];
                
            }];

        }else{
            
            //设置睡眠时间
            XMRTimePiker *piker=[[XMRTimePiker alloc]init];
            
            piker.delegate=self;
            
            [piker showTime];
        }
        
    }
    if (indexPath.section == 2) {
        
        if (indexPath.row == 0) {
            
                NSArray *QArray=[[NSArray alloc]initWithObjects:@"开",@"关", nil];
                
                SSPopup* selection=[[SSPopup alloc]init];
                selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
                
                selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
                selection.SSPopupDelegate=self;
                [self.view  addSubview:selection];
                
                [selection CreateTableview:QArray withSender:self.view  withTitle:@"每晚9：30提醒" setCompletionBlock:^(int tag){
                    
                    if (tag == 0) {
                        
                        [UnityTool setStringValueForConfigurationKey:@"sporttips" WithValue:[NSString stringWithFormat:@"开"]];
                    }else if (tag == 1){
                        [UnityTool setStringValueForConfigurationKey:@"sporttips" WithValue:[NSString stringWithFormat:@"关"]];
                    }
                    [self.tableView reloadData];
                    
                }];
        }else{
            
            NSArray *QArray=[[NSArray alloc]initWithObjects:@"开",@"关", nil];
            
            SSPopup* selection=[[SSPopup alloc]init];
            selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
            
            selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
            selection.SSPopupDelegate=self;
            [self.view  addSubview:selection];
            
            [selection CreateTableview:QArray withSender:self.view  withTitle:@"每早上9：30提醒" setCompletionBlock:^(int tag){
                
                if (tag == 0) {
                    
                    [UnityTool setStringValueForConfigurationKey:@"sleeptips" WithValue:[NSString stringWithFormat:@"开"]];
                }else if (tag == 1){
                    [UnityTool setStringValueForConfigurationKey:@"sleeptips" WithValue:[NSString stringWithFormat:@"关"]];
                }
                [self.tableView reloadData];
                
            }];

        }
        
    }
    if (indexPath.section == 3) {
        
        if (indexPath.row == 0) {
            SetUpViewController *vc = [[SetUpViewController alloc]init];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
        
    }
}
#pragma mark- actionSheet delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex == 0) {
        
          [UnityTool setBoolValueForConfigurationKey:@"bangding" WithValue:NO];
        [self.tableView reloadData];
    }
}
//睡眠代理
-(void)XMSelectTimesViewSetOneLeft:(NSString *)oneLeft andOneRight:(NSString *)oneRight andTowLeft:(NSString *)towLeft andTowRight:(NSString *)towRight{
    
    self.sleepTargetStr=[NSString stringWithFormat:@"%@:%@-%@:%@",oneLeft,oneRight,towLeft,towRight];
    [UnityTool setStringValueForConfigurationKey:@"time" WithValue:[NSString stringWithFormat:@"%@:%@-%@:%@",oneLeft,oneRight,towLeft,towRight]];
    [self.tableView reloadData];
    
}
#pragma mark - *********************响应事件*********************
-(void)gotoAddequipmentViewController
{
    AddequipmentViewController *vc = [[AddequipmentViewController alloc]init];
    vc.hidesBottomBarWhenPushed = YES;
    // 现实block
    // 等待回调
    vc.block = ^(AddequipmentMassage *user){
        
        // block回调
        self.NameStr = user.AddequipmentName;
        self.MacStr = user.AddequipmentMacStr;
        [self.cellbgview removeFromSuperview];
        self.isLock = YES;
        [self.tableView reloadData];
    };
    
    [self.navigationController pushViewController:vc animated:YES];

    
    
}

#pragma mark - *********************懒加载*********************
//开启运动提醒
- (SleepResultNotifyView *)sleepview
{
    if (!_sleepview) {
        _sleepview = [SleepResultNotifyView initFromXIB];
        CGRect bounds = _addView.bounds;
        bounds.size.width = KScreenWidth - 20;
        bounds.size.height = 100;
        _sleepview.bounds = bounds;
        self.sleepview.layer.cornerRadius = 10;
        self.sleepview.layer.masksToBounds = YES;
        if (self.sleepview.sleepSwith.on == YES) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.sleepview.titleLable.text =@"开";
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                self.sleepview.titleLable.text =@"关";
            });
        }
        [self.sleepview.okButton addTarget:self action:@selector(editPersonName) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _sleepview;
}
-(void)editPersonName
{
   
    [self popViewDismiss];
    
    
}
//开启睡眠提醒
- (SportsResultNotifyView *)addView
{
    if (!_addView) {
        _addView = [SportsResultNotifyView initFromXIB];
        CGRect bounds = _addView.bounds;
        bounds.size.width = KScreenWidth - 20;
        bounds.size.height = 100;
        _addView.bounds = bounds;
        self.addView.layer.cornerRadius = 10;
        self.addView.layer.masksToBounds = YES;
        if (self.addView.sportSwith.on == YES) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.addView.titleLable.text =@"开";
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                self.addView.titleLable.text =@"关";
            });
        }
        [self.addView.okbutton addTarget:self action:@selector(editPersonName) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _addView;
}
#pragma mark - *********************网络模型*********************

@end
