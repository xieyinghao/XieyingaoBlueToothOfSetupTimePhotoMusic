//
//  UserMassageViewController.h
//  Fibit
//
//  Created by xieyingze on 16/11/23.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TSBaseViewController.h"
@interface UserMassageViewController : TSBaseViewController

@end
