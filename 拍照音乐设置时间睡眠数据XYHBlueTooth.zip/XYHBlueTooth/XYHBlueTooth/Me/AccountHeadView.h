//
//  AccountHeadView.h
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountHeadView : UIView
@property (weak, nonatomic) IBOutlet UIView *headiconView;

@property (weak, nonatomic) IBOutlet UIView *hightView;
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UIImageView *headIcon;//头像
@property (weak, nonatomic) IBOutlet UILabel *nameLable;//用户名
@property (weak, nonatomic) IBOutlet UIButton *userButton;//个人信息>
@property (weak, nonatomic) IBOutlet UILabel *stepNumber;//日均步数
@property (weak, nonatomic) IBOutlet UILabel *totalNumer;//总英里数
@property (weak, nonatomic) IBOutlet UILabel *daysNumber;//达标天数
+ (id)initFromXIB;
@end
