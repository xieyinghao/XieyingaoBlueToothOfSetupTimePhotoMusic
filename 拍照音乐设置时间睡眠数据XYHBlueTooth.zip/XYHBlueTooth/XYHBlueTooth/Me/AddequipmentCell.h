//
//  AddequipmentCell.h
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddequipmentCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *AddequipmentButton;

@end
