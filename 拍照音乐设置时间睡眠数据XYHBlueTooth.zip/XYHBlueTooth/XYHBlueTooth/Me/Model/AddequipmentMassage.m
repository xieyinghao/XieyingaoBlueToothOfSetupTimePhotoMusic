//
//  AddequipmentMassage.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/29.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "AddequipmentMassage.h"

@implementation AddequipmentMassage

@end
