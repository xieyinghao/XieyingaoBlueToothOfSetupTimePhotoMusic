//
//  AddequipmentMassage.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/29.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddequipmentMassage : NSObject
@property (nonatomic, strong) NSString *AddequipmentName;

@property (nonatomic, strong) NSString *AddequipmentMacStr;

@end
