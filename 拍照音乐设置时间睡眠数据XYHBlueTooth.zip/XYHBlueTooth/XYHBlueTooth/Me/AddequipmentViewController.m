//
//  AddequipmentViewController.m
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "AddequipmentViewController.h"
#import "EquipmentCell.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "LKBubbleInfo.h"
#import "LKBubbleView.h"
#import "NSData+TSExtension.h"
#import "AddequipmentMassage.h"
#import "UnityTool.h"
@interface AddequipmentViewController ()<CBCentralManagerDelegate,UITableViewDelegate,UITableViewDataSource,CBCentralManagerDelegate> {
    
    NSMutableArray *peripherals;
    NSMutableArray *peripheralsAD;
}
/** 中心设备管理者*/
@property (nonatomic, strong) CBCentralManager *centerManager;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)CBPeripheral *peripheral;
@property(nonatomic,strong)CBCharacteristic *characteristic;
@property(nonatomic,strong) UIActivityIndicatorView *testActivityIndicator;
@property(nonatomic,strong)NSMutableArray *characteristicArr;
@end
static NSString *ServicesUUID   = @"FFF0";// heart 服务UUID
static NSString *NotifyUUID = @"FFF1";// 通知 通知UUID
static NSString *WriteUUID   = @"FFF2";//写    服务UUID
@implementation AddequipmentViewController
//4个字节Bytes 转 int
unsigned int  TCcbytesValueToInt(Byte *bytesValue) {
    unsigned int  intV;
    intV = (unsigned int ) ( ((bytesValue[3] & 0xff)<<24)
                            |((bytesValue[2] & 0xff)<<16)
                            |((bytesValue[1] & 0xff)<<8)
                            |(bytesValue[0] & 0xff));
    return intV;
}
-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];

    peripherals = nil;
    self.tableView = nil;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    self.characteristicArr = [NSMutableArray array];
    peripherals = [[NSMutableArray alloc]init];
    peripheralsAD = [[NSMutableArray alloc]init];
    [theManager stopScan];
    self.view.backgroundColor = [UIColor whiteColor];

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"搜索"] style:UIBarButtonItemStyleDone target:self action:@selector(search)];
    
    self.title = @"搜索设备";
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 30,ScreenW , ScreenH)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
       self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
//    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"EquipmentCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    [self.view addSubview:self.tableView];
    
    //菊花转
    
     UIView *tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 0)];
    
    self.testActivityIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
     self.testActivityIndicator.center = CGPointMake(ScreenW*0.5,10);//只能设置中心，不能设置大小
     self.testActivityIndicator.color = [UIColor colorWithRed:53/255.0 green:148/255.0 blue:184/255.0 alpha:1]; // 改变圈圈的颜色为红色； iOS5引入
    
    [tableHeaderView addSubview: self.testActivityIndicator];
    self.tableView.tableHeaderView  = tableHeaderView;
    
}

-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state == CBManagerStatePoweredOn) {
        
        self.title = @"开始扫描";
        [theManager scanForPeripheralsWithServices:nil options:nil];
        
        
    }else{
        
        self.title = @"未开启蓝牙";
    }
}
-(void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    self.title = @"正在扫描中...";
    self.peripheral = peripheral;
    self.peripheral.delegate = self;
//    if ([peripheral.name isEqualToString:@"SMART"]) {
//        [self insertTableView:peripheral advertisementData:advertisementData];
//        NSLog(@"==========%@=======%@",peripheral.name,peripheral.identifier);
//    }
    [self insertTableView:peripheral advertisementData:advertisementData];
    NSLog(@"==========%@=======%@",peripheral.name,peripheral.identifier);
}
#pragma mark -UIViewController 方法
//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData {
    if(![peripherals containsObject:peripheral]){
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        [peripherals addObject:peripheral];
        [peripheralsAD addObject:advertisementData];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return peripherals.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    EquipmentCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"cell"];
    //    TSLog(@"peripherals - %@", peripherals);
    CBPeripheral *peripheral = [peripherals objectAtIndex:indexPath.row];
    //    TSLog(@"peripheral --- %@",peripheral);
    NSDictionary *ad = [peripheralsAD objectAtIndex:indexPath.row];
    
    cell.backgroundView = nil;
    cell.backgroundColor = [UIColor clearColor];
    
    if (!cell) {
        cell = [[EquipmentCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.backgroundView = nil;
        cell.backgroundColor = [UIColor clearColor];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
        [cell setSeparatorInset:UIEdgeInsetsZero];
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
        [cell setLayoutMargins:UIEdgeInsetsZero];
    NSString *localName;
    localName = [NSString stringWithFormat:@"%@",[ad objectForKey:@"kCBAdvDataLocalName"]];
    cell.textColor = [UIColor blueColor];
    cell.macLable.text =[NSString stringWithFormat:@"%@",peripheral.identifier];
    cell.name.text = localName;
    [cell.contectButton addTarget:self action:@selector(conntectBle) forControlEvents:UIControlEventTouchUpInside];

    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //停止扫描
    [theManager cancelPeripheralConnection:self.peripheral];

    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    CBPeripheral *peripheral = [peripherals objectAtIndex:indexPath.row];
    NSDictionary *ad = [peripheralsAD objectAtIndex:indexPath.row];
    NSString *localName;
    localName = [NSString stringWithFormat:@"%@",[ad objectForKey:@"kCBAdvDataLocalName"]];
    //信息存模型
    AddequipmentMassage *massage = [[AddequipmentMassage alloc]init];
    massage.AddequipmentName = localName;
    massage.AddequipmentMacStr = [NSString stringWithFormat:@"%@",peripheral.identifier];
    // 反向传值
    // 判断block是否存在
    if (_block) {
        
        // 调用block
        _block(massage);
    }

    //连接设备
    [theManager stopScan];
    [theManager connectPeripheral:self.peripheral options:nil];
    [self.testActivityIndicator stopAnimating];
    [self.testActivityIndicator hidesWhenStopped];
    self.title = @"正在连接...";
    
    //绑定
    [UnityTool shareInstance];
    [UnityTool setBoolValueForConfigurationKey:@"bangding" WithValue:YES];
    [UnityTool  setStringValueForConfigurationKey:@"bangdingName" WithValue:localName];
     [UnityTool  setStringValueForConfigurationKey:@"bangdingID" WithValue:peripheral.identifier.UUIDString];
    [self.navigationController popViewControllerAnimated:YES];
}
//连接设备
-(void)conntectBle
{

        [theManager stopScan];
        [theManager connectPeripheral:self.peripheral options:nil];
        [self.testActivityIndicator stopAnimating];
        [self.testActivityIndicator hidesWhenStopped];
        self.title = @"正在连接...";
    
}
//连接到Peripherals-成功
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    self.title = @"连接成功!";
    NSLog(@"连接外设成功！%@",peripheral.name);
    self.peripheral = peripheral;
    [peripheral setDelegate:self];
    [peripheral discoverServices:nil];
    
}

//扫描到服务
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    if (error)
    {
        NSLog(@"扫描外设服务出错：%@-> %@", peripheral.name, [error localizedDescription]);
        self.title = @"find services error.";
        return;
    }
    NSLog(@"扫描到外设服务：%@ -> %@",peripheral.name,peripheral.services);
    for (CBService *service in peripheral.services) {
        if ([service.UUID.UUIDString isEqualToString:ServicesUUID]) {
            
            [peripheral discoverCharacteristics:nil forService:service];
              NSLog(@"开始扫描外设服务的特征 %@...",peripheral.name);
        }
    }

}
//扫描到特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (error)
    {
        NSLog(@"扫描外设的特征失败！%@->%@-> %@",peripheral.name,service.UUID, [error localizedDescription]);
        self.title = @"find characteristics error.";
        return;
    }
    
    NSLog(@"扫描到外设服务特征有：%@->%@->%@",peripheral.name,service.UUID,service.characteristics);
    
    //获取Characteristic的值
    for (CBCharacteristic *characteristic in service.characteristics){
        {
            self.characteristic = characteristic;

            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            [peripheral readValueForCharacteristic:characteristic];
            if ([characteristic.UUID.UUIDString isEqualToString:NotifyUUID])
            {
                
                [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            }
            
            //读取时间
            else if ([characteristic.UUID.UUIDString isEqualToString:WriteUUID])
            {
                // 读取时间：
//                Byte byte[3];
//                byte[0] = 0X89;
//                byte[1] = 0x00;
//                byte[2] = 0x00;
//                NSData *data = [NSData dataWithBytes:byte length:3];
//                [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
                
                
//                 读取步数：
//                Byte byte1[4];
//                byte1[0] = 0xC6;
//                byte1[1] = 0x01;
//                byte1[2] = 0x08;
//                byte1[3] = 0x08;
//                NSData *data1 = [NSData dataWithBytes:byte1 length:4];
//                [peripheral writeValue:data1 forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
                
                //  读取设备蓝牙地址
//                Byte bytedMAC[3];
//                bytedMAC[0] = 0xFA;
//                bytedMAC[1] = 0x00;
//                bytedMAC[2] = 0x00;
//                NSData *dataMAC = [NSData dataWithBytes:bytedMAC length:3];
//                [peripheral writeValue:dataMAC forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
                
                //  切换实时传感器检测状态
//                Byte byteHeart[8];
//                byteHeart[0] = 0x93;
//                byteHeart[1] = 0x05;
//                byteHeart[2] = 0x00;
//                byteHeart[3] = 0x00;
//                byteHeart[4] = 0x00;
//                byteHeart[5] = 0x00;
//                byteHeart[6] = 0x00;
//                byteHeart[7] = 0x00;
//                NSData *dataHeart = [NSData dataWithBytes:byteHeart length:8];
//                [peripheral writeValue:dataHeart forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
                
                // 读取心率数据
//                Byte byteHeartlv[20];
//                byteHeartlv[0] = 0x99;
//                byteHeartlv[1] = 0x00;
//                byteHeartlv[3] = 0x00;
//                byteHeartlv[4] = 0x00;
//                byteHeartlv[5] = 0x00;
//                byteHeartlv[6] = 0x00;
//                byteHeartlv[7] = 0x00;
//                byteHeartlv[8] = 0x00;
//                byteHeartlv[9] = 0x00;
//                byteHeartlv[10] = 0x00;
//                byteHeartlv[11] = 0x00;
//                byteHeartlv[12] = 0x00;
//                byteHeartlv[13] = 0x00;
//                byteHeartlv[14] = 0x00;
//                byteHeartlv[15] = 0x00;
//                byteHeartlv[16] = 0x00;
//                byteHeartlv[17] = 0x00;
//                byteHeartlv[18] = 0x00;
//                byteHeartlv[19] = 0x00;
//                NSData *dataHeartlv = [NSData dataWithBytes:byteHeartlv length:20];
//                [peripheral writeValue:dataHeartlv forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];

            }
        }
    }
    
    }
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    
    if (error) {
        
        NSLog(@"Error writing characteristic value: %@",
              
              [error localizedDescription]);
        
    }
    
    
    
}
#pragma mark 设备信息处理
//扫描到具体的值
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    if (error) {
        NSLog(@"扫描外设的特征失败！%@-> %@",peripheral.name, [error localizedDescription]);
        self.title = @"find value error.";
        return;
    }
    NSLog(@"==characteristic.UUID.UUIDString：%@===characteristic.value：%@",characteristic.UUID.UUIDString,characteristic.value);
    [self.characteristicArr addObject:characteristic.value];
    
    self.title = @"信息扫描完成";
    NSLog(@"=========%@==========",self.characteristicArr);
    if ([characteristic.UUID.UUIDString isEqualToString:@"FFF1"]) {
        
        NSData *data = characteristic.value;
        NSString *value = [NSString stringWithFormat:@"%@",characteristic.value];
        NSLog(@"Value - %@----%@",value,data);
        if (data) {
            Byte *byte = (Byte *)[data bytes];
            Byte b[] = {byte[2],byte[3],byte[4]};
            NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
            NSString *str = [adata ConvertToNSString];
            UInt64 weight = strtoul([str UTF8String], 0, 16);
            NSLog(@"==========步数:%ld==========",weight);
        }
   
        
    }
    }
-(void)search
{
//    [self.characteristicArr removeAllObjects];
//    [peripherals removeAllObjects];
//    [peripheralsAD  removeAllObjects];
   theManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
     [ self.testActivityIndicator startAnimating]; // 开始旋转
    
}
-(UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}
-(void)goback
{
    [self.navigationController popViewControllerAnimated:YES];
    
}

#pragma mark - 绑定设备
- (void)bindScale {
//    WeakSelf
//    // 请求地址
//    NSString *url = [TSInterfaceUtil getUrlWithSuffix:URL_BIND_Device];
//    // 请求参数
//    NSMutableDictionary *params = [NSMutableDictionary dictionary];
//    params[@"token"] = token;
//    params[@"imei"] = imei;
//    params[@"deviceMac"] = self.macstr;
//    params[@"deviceAlias"] = @"体脂秤";
//    params[@"deviceType"] = @(ELECTRONIC_SCALE);
//    TSLog(@"体脂秤 - %@", self.macstr);
//    TSLog(@"体脂秤的类型 - %ld", (long)ELECTRONIC_SCALE);
//    
//    [weakSelf.manager POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSString *description = responseObject[@"result"][@"description"];
//        [MBProgressHUD showMsg:description toView:nil];
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        if (error) {
//            TSLog(@"%@",error);
//        }
//    }];
}
#pragma mark - 解绑设备
- (void)unBindDevice {
//    WeakSelf
//    NSString *token = [UserDefaults objectForKey:@"userToken"];
//    NSString *imei = [UserDefaults objectForKey:@"deviceUUID"];
//    
//    if (!token && !self.macString) {
//        return;
//    }
//    
//    // 请求地址
//    NSString *url = [TSInterfaceUtil getUrlWithSuffix:URL_UNBIND_Device];
//    // 请求参数
//    NSMutableDictionary *params = [NSMutableDictionary dictionary];
//    
//    params[@"token"] = token;
//    params[@"imei"] = imei;
//    params[@"deviceMac"] = self.macString;
//    params[@"deviceAlias"] = @"血压计";
//    params[@"deviceType"] = @(BLOOD_PRESSUER);
//    
//    [weakSelf.manager POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        
//        NSString *description = responseObject[@"result"][@"description"];
//        [MBProgressHUD showMsg:description toView:nil];
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        if (error) {
//            TSLog(@"%@",error);
//        }
//    }];
}

@end
