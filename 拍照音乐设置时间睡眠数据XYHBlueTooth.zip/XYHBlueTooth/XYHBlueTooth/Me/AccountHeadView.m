//
//  AccountHeadView.m
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import "AccountHeadView.h"

@implementation AccountHeadView


+ (id)initFromXIB
{
    NSArray* xibs = [[NSBundle mainBundle]loadNibNamed:@"AccountHeadView" owner:self options:nil];
    
    return xibs[0];
}

@end
