//
//  BorderView.h
//  XYZPayDemo
//
//  Created by xieyingze on 16/8/10.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BorderView : UIView

@end
