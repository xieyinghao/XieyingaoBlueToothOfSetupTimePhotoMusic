//
//  UIButton+Style.h
//  PayDemo
//
//  Created by xieyingze on 16/8/10.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Style)

- (void)setSearchStyleOfSelected;

- (void)setSearchStyleOfNormal;

- (void)setSearTimeStyle;

- (void)setDisableStyle;

- (void)setDefaultStyle;

@end
