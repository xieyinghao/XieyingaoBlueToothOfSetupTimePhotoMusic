//
//  UIImage+ColorImage.h
//  GTG
//
//  Created by xieyingze on 16/7/4.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ColorImage)

+ (UIImage *)returnImageFromColor:(UIColor *)color;

@end
