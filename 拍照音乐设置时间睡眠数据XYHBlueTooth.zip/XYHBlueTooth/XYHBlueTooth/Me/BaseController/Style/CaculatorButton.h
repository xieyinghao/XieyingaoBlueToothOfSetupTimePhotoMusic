//
//  CaculatorButton.h
//  PayDemo
//
//  Created by xieyingze on 16/8/2.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CaculatorButton : UIButton

@end
