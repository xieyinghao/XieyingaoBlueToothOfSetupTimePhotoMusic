//
//  BorderView.m
//  XYZPayDemo
//
//  Created by xieyingze on 16/8/10.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "BorderView.h"

@implementation BorderView

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    self.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.layer.borderWidth = 0.5;
    self.layer.cornerRadius = 4;
    self.layer.masksToBounds = YES;
}

@end
