//
//  RMPopController.h
//  XHQB
//
//  Created by 陈波 on 15/9/14.
//  Copyright (c) 2015年 chenbo. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum :NSInteger{
    RMPopControllerLocationTypeTop,
    RMPopControllerLocationTypeCenter,
}RMPopControllerLocationType;

typedef enum : NSUInteger {
    RMPopControllerAnimationTypeDefault,
    RMPopControllerAnimationTypeZoom,
} RMPopControllerAnimationType;

@interface RMPopController : NSObject

@property (nonatomic, assign)RMPopControllerAnimationType popAnimationType;
@property (nonatomic, assign)RMPopControllerLocationType locationType;

-(void)pop:(UIView*)view locationType:(RMPopControllerLocationType)locationType andDismiss:(dispatch_block_t) block;

-(void)dismissDefault;

@end
