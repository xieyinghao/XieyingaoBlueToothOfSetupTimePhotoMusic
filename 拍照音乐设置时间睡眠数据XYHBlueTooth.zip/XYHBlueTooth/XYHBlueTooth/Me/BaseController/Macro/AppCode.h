//
//  AppCode.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppCode_h
#define AppCode_h

/**
 *  网络请求返回代码
 */
#define kSuccessCode    @"1"
//#define kOutTimeCode    @"000001"

#endif /* AppCode_h */
