
//
//  AppTag.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppTag_h
#define AppTag_h

/**
 *  Button的Tag值
 */
#define KButtonTag          10000

/**
 *  TextFiled的Tag值
 */
#define KTextFiledTag       10000

/**
 *  AlertView的Tag值
 */
#define KAlertViewTag       10000



#endif /* AppTag_h */
