//
//  AppName.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppName_h
#define AppName_h

/**
 *  image名字
 */
#define Image_Back  @"back"

/**
 *  通知中心Name
 */
#define Notification_UserLogin  @"USERID"


#endif /* AppName_h */
