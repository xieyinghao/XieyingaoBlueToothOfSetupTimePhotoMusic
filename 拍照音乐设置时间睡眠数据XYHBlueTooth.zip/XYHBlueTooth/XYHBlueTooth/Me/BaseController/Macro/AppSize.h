//
//  AppSize.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//
#import "AppDevice.h"

#ifndef AppSize_h
#define AppSize_h

/**
 *  屏幕的长宽
 */
#define KScreenWidth    [UIScreen mainScreen].bounds.size.width

#define KScreenHeight   [UIScreen mainScreen].bounds.size.height

#define KTabelViewCellHeight      (IPHONE5||IPHONE4?44:49)

/**
 *  控件长宽
 */
#define KTabBarDefaultHeight    49

/**
 *
 */
#define kBtnWidthAndHeight 80
#define kBtnX 100
#define kBtnNX 80
#define kBtnSeachY 120
#define kBtnHistoryY kBtnSeachY + 160

#endif /* AppSize_h */
