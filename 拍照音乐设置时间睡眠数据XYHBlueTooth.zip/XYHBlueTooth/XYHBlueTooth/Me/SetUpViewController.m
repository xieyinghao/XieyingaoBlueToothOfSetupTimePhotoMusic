//
//  SetUpViewController.m
//  Fibit
//
//  Created by xieyingze on 16/11/23.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "SetUpViewController.h"
#import "GUAAlertView.h"
#import "SSPopup.h"
#import "UnityTool.h"
#import "HelpViewController.h"
#import "SetUpViewCell.h"
#import "UWDatePickerView.h"
#import "BlueToothManager.h"
@interface SetUpViewController ()<UITableViewDelegate,UITableViewDataSource,UWDatePickerViewDelegate>
{
    UWDatePickerView *_pickerView;
}

@property(nonatomic,strong)UITableView *tableView;
@end

@implementation SetUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   self.title = @"设置";
    self.view.backgroundColor = [UIColor whiteColor];
     [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    self.tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
//    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"SetUpViewCell" bundle:nil] forCellReuseIdentifier:@"SetUpViewCell"];
    self.tableView.rowHeight = 54;
    [self.view addSubview:self.tableView];
    
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 0.5)];
     line.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    self.tableView.tableFooterView = line;
    
    //初始化
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    
    //扫描
    [manager scan];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 5;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    SetUpViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SetUpViewCell"];
//    cell.accessoryType= UITableViewCellAccessoryDisclosureIndicator;
    NSArray *titleArry = @[@"设备时间设置",@"APP更新",@"固件检测",@"使用帮助",@"关于"];
    NSArray *timeArray = @[[UnityTool getStringValueForConfigurationKey:@"date"],@"",@"",@"",@""];
       cell.titleLable.text  = titleArry[indexPath.row];
    cell.timeLable.text = timeArray[indexPath.row];
    cell.titleLable.font = [UIFont systemFontOfSize:15];
    cell.titleLable.textColor = [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
       
       
         [self setupDateView:DateTypeOfStart];
        
    }
    if (indexPath.row == 1) {
       
        GUAAlertView *v = [GUAAlertView alertViewWithTitle:@"温馨提示"
                                                   message:@"该版本已经是最新"
                                               buttonTitle:@"知道了！"
                                       buttonTouchedAction:^{
                                           NSLog(@"button touched");
                                       } dismissAction:^{
                                           NSLog(@"dismiss");
                                       }];
        [v show];

    }
    if (indexPath.row == 3) {
        
        HelpViewController *vc = [[HelpViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.row == 4) {
        
       
    }
    
}
- (void)setupDateView:(DateType)type {
    
    _pickerView = [UWDatePickerView instanceDatePickerView];
    _pickerView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [_pickerView setBackgroundColor:[UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1]];
    _pickerView.delegate = self;
    _pickerView.type = type;
    [self.view addSubview:_pickerView];
    
}

- (void)getSelectDate:(NSString *)date type:(DateType)type {
    
//    NSLog(@"时间%@",date);
    NSString *timeStr = [NSString stringWithFormat:@"%@",date];
    [UnityTool setStringValueForConfigurationKey:@"date" WithValue:timeStr];
    NSLog(@"========时间%@===========",timeStr);
    //截取年
    NSString *b = [timeStr substringToIndex:4];
    NSString *c = [b substringFromIndex:2];//年
    NSLog(@"\n b: %@",b);
    NSLog(@"\n b: %@",c);
    
    NSString *months = [timeStr substringToIndex:7];
    NSString *month = [months substringFromIndex:5];//年
    NSLog(@"======月:%@====",month);
    
    NSString *dates = [timeStr substringToIndex:10];
    NSString *date0 = [dates substringFromIndex:8];//日
    NSLog(@"======日:%@====",date0);
    
    NSString *hours = [timeStr substringToIndex:13];
    NSString *hour = [hours substringFromIndex:11];//小时
    NSLog(@"======小时:%@====",hour);

    NSString *seconds = [timeStr substringToIndex:16];
    NSString *second = [seconds substringFromIndex:14];//分
    NSLog(@"======分:%@====",second);
    
    [self editTimeYear:[c intValue] And:[month intValue] AndDate:[date0 intValue] AndHour:[hour intValue] AndSecond:[second intValue]];
    
    
    
    [self.tableView reloadData];
    switch (type) {
        case DateTypeOfStart:
            // TODO 日期确定选择
            break;
            
        case DateTypeOfEnd:
            // TODO 日期取消选择
            break;
        default:
            break;
    }
}
#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
    CBPeripheral *peripheral = peripherals.firstObject;

    [weakManager connect:peripheral];
    
    
}
-(void)editTimeYear:(NSInteger)year And:(NSInteger)month AndDate:(NSInteger)date AndHour:(NSInteger)hour AndSecond:(NSInteger)second
{
//    NSString *yeasStr = [self ToHex:year];
//    NSData *datayears = [self hexToBytes:yeasStr];
//    Byte *byteyears = (Byte *)[datayears bytes];
//    
//    NSLog(@"====byteyears=========%@==========",byteyears);
    
    
    
    
     NSString *uuid = @"FFF2";
    //设置时间
    Byte byte1[10];
    byte1[0] = 0XC2;
    byte1[1] = 0X07;
    byte1[2] = year;//16年
    byte1[3] = month;//12月
    byte1[4] = date;//13日
    byte1[5] = hour;//14时
    byte1[6] = second;//41分
    byte1[7] = 0x00;//14秒
    byte1[8] = 0x01;//周二
    byte1[9] = byte1[2]^byte1[3]^byte1[4]^byte1[5]^byte1[6]^byte1[7]^byte1[8];
    NSData *data1 = [NSData dataWithBytes:byte1 length:10];
//
 [[BlueToothManager shareManager] writeData:data1 characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
}
//将十进制转化为十六进制
- (NSString *)ToHex:(int)tmpid
{
    NSString *nLetterValue;
    NSString *str =@"";
    int ttmpig;
    for (int i = 0; i<9; i++) {
        ttmpig=tmpid%16;
        tmpid=tmpid/16;
        switch (ttmpig)
        {
            case 10:
                nLetterValue =@"A";break;
            case 11:
                nLetterValue =@"B";break;
            case 12:
                nLetterValue =@"C";break;
            case 13:
                nLetterValue =@"D";break;
            case 14:
                nLetterValue =@"E";break;
            case 15:
                nLetterValue =@"F";break;
            default:
                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
                
        }
        str = [nLetterValue stringByAppendingString:str];
        if (tmpid == 0) {
            break;
        }
    }
    //不够一个字节凑0
    if(str.length == 1){
        return [NSString stringWithFormat:@"0%@",str];
    }else{
        return str;
    }
}
//NSString转NSData
- (NSData *)hexToBytes:(NSString *)str
{
    NSMutableData* data = [NSMutableData data];
    int idx;
    for (idx = 0; idx+2 <= str.length; idx+=2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString* hexStr = [str substringWithRange:range];
        NSScanner* scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}
//int转NSData
- (NSData *) setId:(int)Id {
    //用4个字节接收
    Byte bytes[4];
    bytes[0] = (Byte)(Id>>24);
    bytes[1] = (Byte)(Id>>16);
    bytes[2] = (Byte)(Id>>8);
    bytes[3] = (Byte)(Id);
    NSData *data = [NSData dataWithBytes:bytes length:4];
    return data;
}
@end
