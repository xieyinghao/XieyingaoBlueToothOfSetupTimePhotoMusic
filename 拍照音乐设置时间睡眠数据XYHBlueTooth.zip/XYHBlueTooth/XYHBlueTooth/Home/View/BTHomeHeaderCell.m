//
//  BTHomeHeaderCell.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BTHomeHeaderCell.h"
#import "BTPercentView.h"
#import "UILabel+Style.h"
#import "UIView+Shake.h"
#import "UIView+HeartBeat.h"
#import "UnityTool.h"
#define kUI_BTHomeHeaderCellH   240

@interface BTHomeHeaderCell ()

@property (nonatomic, strong) BTPercentView *percentView;

@property (nonatomic, strong) UIImageView *centerImageView;

@property (nonatomic, strong) UILabel *stepNumberLabel;

@end

@implementation BTHomeHeaderCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubView];
    }
    return self;
}

- (void)initSubView
{
    [self addSubview:self.percentView];
    [self addSubview:self.stepNumberLabel];
    
    __weak typeof (self) weakself = self;
    [self.stepNumberLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.percentView.mas_bottom).offset(10);
        make.left.equalTo(@20);
        make.right.equalTo(@-20);
        make.height.equalTo(@25);
    }];
}

#pragma mark - Getter&&Setter

- (BTPercentView *)percentView
{
    if (!_percentView) {
        
        CGFloat percentViewH = 160;
        
        _percentView = [[BTPercentView alloc] initWithFrame:CGRectMake((kUI_WIDTH - percentViewH)/2, 30, percentViewH, percentViewH) andPercent:0.5 andColor:kCOLOR_heavy_blue];
    }
    return _percentView;
}

- (UILabel *)stepNumberLabel
{
    if (!_stepNumberLabel) {
        _stepNumberLabel = [UILabel new];
        [_stepNumberLabel setLabelStyle:@"" textColor:kCOLOR_heavy_green textFont:kFONT_system(16.f) texrAlignment:NSTextAlignmentCenter];
    }
    return _stepNumberLabel;
}

- (void)setStepNumber:(NSInteger)stepNumber
{
    _stepNumber = stepNumber;
    
    float total = [[UnityTool getStringValueForConfigurationKey:@"sport"] floatValue];
//    [self.percentView reloadViewWithPercent:(stepNumber/10000.f)];
     [self.percentView reloadViewWithPercent:(stepNumber/total)];
    self.stepNumberLabel.text = [NSString stringWithFormat:@"今天已运动%ld步",stepNumber];
    [self.stepNumberLabel heartBeat:@3];
    //抖动效果
//    [ self.stepNumberLabel shakeWithOptions:SCShakeOptionsDirectionHorizontal | SCShakeOptionsForceInterpolationNone | SCShakeOptionsAtEndContinue force:0.1 duration:100 iterationDuration:0.03 completionHandler:nil];
}

@end
