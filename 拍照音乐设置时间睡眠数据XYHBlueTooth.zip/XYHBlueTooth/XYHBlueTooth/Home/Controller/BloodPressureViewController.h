//
//  BloodPressureViewController.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BabyBluetooth.h"
@interface BloodPressureViewController : UIViewController {
@public
    BabyBluetooth *baby;
}
/** 服务*/
@property __block NSMutableArray *services;
/** 当前设备*/
@property (nonatomic,strong) CBPeripheral *currPeripheral;
/** 特征值*/
@property (nonatomic,strong) CBCharacteristic *characteristic;

@end
