//
//  BloodPressureViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
/** 防止循环引用*/
#define WeakSelf __weak __typeof(self) weakSelf = self;
#define channelOnPeropheralView @"peripheralView"
#import "BloodPressureViewController.h"
#import "wendu_yuan2.h"
#import "UICountingLabel.h"
#define MAS_SHORTHAND
#import "Masonry.h"
#import "UIColor+Hex.h"
@interface BloodPressureViewController ()
@property (nonatomic,strong) wendu_yuan2 *progressView;
@property (nonatomic,strong) UIImageView *boardImgView;
@property (nonatomic,strong) UICountingLabel *pointLab;//分数
@property (nonatomic,strong) UILabel *judgeLab;//评价等级
@property (nonatomic,assign) int point;
@property (nonatomic,strong) UIButton *checkBtn;
@end
static NSString *HeartUUID   = @"1902";// heart 服务UUID
static NSString *HeartNotify = @"1904";// heart 通知UUID
static NSString *ScaleUUID   = @"2002";// 秤    服务UUID
static NSString *ScaleNofity = @"2B02";// 秤    通知UUID
static NSString *ScaleWrite  = @"2B03";// 秤    写UUID
static NSString *SystemID    = @"2A23";// System ID

@implementation BloodPressureViewController
// 视图消失的时候调用
- (void)viewDidDisappear:(BOOL)animated {
    [baby setBlockOnConnectedAtChannel:channelOnPeropheralView block:nil];
    [baby setBlockOnFailToConnectAtChannel:channelOnPeropheralView block:nil];
    [baby setBlockOnDisconnectAtChannel:channelOnPeropheralView block:nil];
    [baby setBlockOnReadValueForCharacteristicAtChannel:channelOnPeropheralView block:nil];
    [baby setBlockOnDiscoverCharacteristicsAtChannel:channelOnPeropheralView block:Nil];
    [baby cancelScan];
    [baby cancelAllPeripheralsConnection];
}
- (void)viewDidLoad {
    [super viewDidLoad];
     self.title = @"血压测量";
    self.view.backgroundColor = [UIColor whiteColor];
    //去除导航栏下滑线
     [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    //设置颜色
   self.view.backgroundColor = [UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1];
    [self initCircleView];
    
    //初始化
    self.services = [[NSMutableArray alloc]init];
    [self babyDelegate];
    
    //开始扫描设备
    [self performSelector:@selector(loadData) withObject:nil afterDelay:2];

}
#pragma mark - ********************babyDelegate**********************
#pragma mark - *********************蓝牙代理方法*********************
-(void)babyDelegate
{
    WeakSelf
    //设置设备连接成功的委托
    [baby setBlockOnConnectedAtChannel:channelOnPeropheralView block:^(CBCentralManager *central, CBPeripheral *peripheral) {
        NSLog(@"设备连接成功");
    }];
    
    //设置设备连接失败的委托
    [baby setBlockOnFailToConnectAtChannel:channelOnPeropheralView block:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        NSLog(@"设备：%@--连接失败,%@",peripheral.name, error);
        
    }];
    
    //设置设备断开连接的委托
    [baby setBlockOnDisconnectAtChannel:channelOnPeropheralView block:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        NSLog(@"设备：%@--断开连接",peripheral.name);
        
        // 开始连接设备
        [weakSelf performSelector:@selector(loadData) withObject:nil afterDelay:2];
        
    }];
    
    //设置发现设service的Characteristics的委托(发现服务里的特征值)
    [baby setBlockOnDiscoverCharacteristicsAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBService *service, NSError *error) {
        
        if([service.UUID isEqual:[CBUUID UUIDWithString:HeartUUID]]) {
            NSLog(@"--- 1902characteristics ---%@", service.characteristics);
            for (CBCharacteristic *charstic in service.characteristics) {
                if ([charstic.UUID isEqual:[CBUUID UUIDWithString:HeartNotify]]) {
                    /** 写入ping 保持长连接*/
                    NSString *value = @"ping";
                    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
                    [peripheral writeValue:data forCharacteristic:charstic type:CBCharacteristicWriteWithResponse];
                }
            }
        }
        if([service.UUID isEqual:[CBUUID UUIDWithString:ScaleUUID]]) {
            NSLog(@"--- 2002characteristics ---%@", service.characteristics);
            for (CBCharacteristic *charstic in service.characteristics) {
                if ([charstic.UUID isEqual:[CBUUID UUIDWithString:ScaleNofity]]) {
                    if(self.currPeripheral.state != CBPeripheralStateConnected) {
                        NSLog(@"设备已经断开连接，请重新连接");
                        return;
                    }
                    weakSelf.self.title = @"测量中...";
                    if (charstic.properties & CBCharacteristicPropertyNotify ||  charstic.properties & CBCharacteristicPropertyIndicate) {
                        
                        if(charstic.isNotifying) {
                            [baby cancelNotify:self.currPeripheral characteristic:charstic];
                        }else {
                            [weakSelf.currPeripheral setNotifyValue:YES forCharacteristic:charstic];
                            [baby notify:self.currPeripheral characteristic:charstic
                                   block:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
                                       
                                       NSData *data = characteristics.value;
                                       NSString *value = [NSString stringWithFormat:@"%@",characteristics.value];
                                       NSLog(@"Value - %@",value);
                                       
                                       if (data) {
                                           
                                           
                                       }
                                   }];
                        }
                    }else {
                        return;
                    }
                    
                }
                // 找到UUID为2B03的特征值
                if ([charstic.UUID isEqual:[CBUUID UUIDWithString:ScaleWrite]]) {
                    // 1.5秒以后发送数据
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        NSLog(@"--- 给设备发送数据 ---");
                        //                        [self sendData];
                        Byte b[5] = {0};
                        b[0] = 0X10;
                        b[1] = 0X01;
                        b[2] = 0X01;
                        b[3] = 0X1E;
                        b[4] = 0XAF;
                        
                        NSData *data = [NSData dataWithBytes:&b length:sizeof(b)];
                        NSLog(@"%@",data);
                        // 将data写入到蓝牙设备中
                        [peripheral writeValue:data forCharacteristic:charstic type:CBCharacteristicWriteWithoutResponse];
                    });
                }
            }
        }
    }];
    //设置读取characteristics的委托
    [baby setBlockOnReadValueForCharacteristicAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
        
        // 2A23是System ID
        if ([characteristics.UUID isEqual:[CBUUID UUIDWithString:SystemID]]) {
            
            [peripheral readValueForCharacteristic:characteristics];
            NSString *value = [NSString stringWithFormat:@"%@",characteristics.value];
            // 拼接mac地址
            NSMutableString *macstr = [[NSMutableString alloc] init];
            [macstr appendString:[[value substringWithRange:NSMakeRange(16, 2)] uppercaseString]];
            [macstr appendString:@":"];
            [macstr appendString:[[value substringWithRange:NSMakeRange(14, 2)] uppercaseString]];
            [macstr appendString:@":"];
            [macstr appendString:[[value substringWithRange:NSMakeRange(12, 2)] uppercaseString]];
            [macstr appendString:@":"];
            [macstr appendString:[[value substringWithRange:NSMakeRange(5, 2)] uppercaseString]];
            [macstr appendString:@":"];
            [macstr appendString:[[value substringWithRange:NSMakeRange(3, 2)] uppercaseString]];
            [macstr appendString:@":"];
            [macstr appendString:[[value substringWithRange:NSMakeRange(1, 2)] uppercaseString]];
            //            TSLog(@"mac地址:%@",macstr);
            if (macstr != nil) {
                
            }
        }
        
    }];
    //扫描选项
    NSDictionary *scanForPeripheralsWithOptions = @{CBCentralManagerScanOptionAllowDuplicatesKey:@YES};
    /*连接选项*/
    NSDictionary *connectOptions = @{CBConnectPeripheralOptionNotifyOnConnectionKey:@YES,
                                     CBConnectPeripheralOptionNotifyOnDisconnectionKey:@YES,
                                     CBConnectPeripheralOptionNotifyOnNotificationKey:@YES};
    
    [baby setBabyOptionsAtChannel:channelOnPeropheralView scanForPeripheralsWithOptions:scanForPeripheralsWithOptions connectPeripheralWithOptions:connectOptions scanForPeripheralsWithServices:nil discoverWithServices:nil discoverWithCharacteristics:nil];
    
}
#pragma mark - *********************响应事件*********************
#pragma mark - 开始连接设备
- (void)loadData {
//    
//    baby.having(self.currPeripheral).and.channel(channelOnPeropheralView).then.connectToPeripherals().discoverServices().discoverCharacteristics().readValueForCharacteristic().discoverDescriptorsForCharacteristic().readValueForDescriptors().begin();
}
#pragma mark - *********************初始化UI界面*********************
-(void)initCircleView
{
    [self.view addSubview:self.boardImgView];
    [self.view addSubview:self.progressView];
    
    [self.boardImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.progressView.mas_centerX);
        make.centerY.mas_equalTo(self.progressView.mas_centerY);
        make.width.mas_equalTo(330);
        make.height.mas_equalTo(330);
    }];
    
    [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.size.mas_equalTo(CGSizeMake(AUTO_3PX(980), AUTO_3PX(980)));
        make.centerX.mas_equalTo(self.view.centerX);
        make.top.mas_equalTo(80);
        make.width.mas_equalTo(self.boardImgView).mas_offset(-30);
        make.height.mas_equalTo(self.boardImgView).mas_offset(-30);
    }];
    self.point = 800;
    self.progressView.progress = (800.0-300)/(850-300.0);
    
    
    self.boardImgView.backgroundColor = [UIColor clearColor];
    [self.view bringSubviewToFront:self.progressView];
    
    [self.progressView addSubview:self.pointLab];
    [self.pointLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(self.progressView.mas_width);
        make.height.mas_equalTo(60);
        make.centerX.equalTo(self.progressView.centerX);
        make.centerY.equalTo(self.progressView.centerY).mas_offset(-10);
    }];
    
    
    [self.progressView addSubview:self.judgeLab];
    [self.judgeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.progressView);
        make.top.mas_equalTo(self.pointLab.mas_bottom);
        make.left.mas_equalTo(self.progressView.mas_left);
    }];
    self.judgeLab.text = @"血压";
    
    [self.view addSubview:self.checkBtn];
    [self.checkBtn addTarget:self action:@selector(startAnim) forControlEvents:UIControlEventTouchUpInside];
    [self.checkBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.view.mas_bottom).mas_offset(-70);
        make.centerX.mas_equalTo(self.view.centerX);
        make.width.mas_equalTo(250);
        make.height.mas_equalTo(66);
    }];
}
-(void)startAnim
{
    self.pointLab.method = UILabelCountingMethodLinear;
    self.pointLab.format = @"%d";
    [self.pointLab countFrom:1 to:self.point withDuration:1.5];
    [self.progressView start];
    
}
#pragma mark - property
-(UIButton *)checkBtn
{
    if (_checkBtn == nil) {
        _checkBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_checkBtn setBackgroundImage:[UIImage imageNamed:@"whiteBtn"] forState:UIControlStateNormal];
        [_checkBtn setTitle:@"开始测量血压" forState:UIControlStateNormal];
        [_checkBtn setTitleColor:[UIColor colorWithHex:0x0d87cd] forState:UIControlStateNormal];
        _checkBtn.titleLabel.font = [UIFont systemFontOfSize:18];
        
        _checkBtn.backgroundColor = [UIColor clearColor];
        _checkBtn.titleEdgeInsets = UIEdgeInsetsMake(-18, 0, 0, 0);
    }
    return _checkBtn;
}
-(wendu_yuan2*)progressView
{
    if (_progressView  == nil) {
        _progressView = [[wendu_yuan2 alloc]init];
        _progressView.backgroundColor = [UIColor clearColor];
        ;
    }
    return _progressView;
}
-(UICountingLabel *)pointLab
{
    if (!_pointLab) {
        _pointLab = [[UICountingLabel alloc]init];
        _pointLab.textAlignment = NSTextAlignmentCenter;
        _pointLab.font = [UIFont systemFontOfSize:60];
        _pointLab.textColor = [UIColor whiteColor];
    }
    return _pointLab;
}
-(UILabel *)judgeLab
{
    if (!_judgeLab) {
        _judgeLab = [[UILabel alloc]init];
        _judgeLab.textAlignment = NSTextAlignmentCenter;
        _judgeLab.font = [UIFont systemFontOfSize:16];
        _judgeLab.textColor = [UIColor whiteColor];
    }
    return _judgeLab;
}
-(UIImageView*)boardImgView
{
    if (_boardImgView  == nil) {
        _boardImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"board"]];
    }
    return _boardImgView;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
