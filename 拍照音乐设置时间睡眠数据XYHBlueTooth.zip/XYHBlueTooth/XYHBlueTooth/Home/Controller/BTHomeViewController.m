//
//  HomeViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
/** 防止循环引用*/
#define WeakSelf __weak __typeof(self) weakSelf = self;
#import "BTHomeViewController.h"
#import "BTHomeHeaderCell.h"
#import "BTHomeContentsCell.h"
#import "UnityTool.h"
#import "WalkViewController.h"
#import "SleepViewController.h"
#import "BloodPressureViewController.h"
#import "HeartRateViewController.h"
#import "NSData+TSExtension.h"
#import "KPIndicatorView.h"
#import "XYHUIImagePickerController.h"
#import "BlueToothManager.h"
//音乐播放
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#define channelOnPeropheralView @"peripheralView"
@interface BTHomeViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>{
    NSMutableArray *peripherals;
    NSMutableArray *peripheralsAD;
    NSString *_username;
    NSTimer *timer;
    BOOL _isEditing;
    
}

@property (nonatomic, strong) KPIndicatorView *kpIndicatorView;
@property(nonatomic,strong)CBPeripheral *peripheral;
@property(nonatomic,strong)CBCharacteristic *characteristic;

@property (nonatomic, copy)   NSString       *deviceName;
@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, strong) NSArray *titleArray;

@property(nonatomic)NSInteger steps;

@property (strong, nonatomic) MPMusicPlayerController *musicPlayerController; //音乐播放器
@property (assign, nonatomic) MPMusicPlaybackState musicPlaybackState; //播放状态
@property (strong, nonatomic) MPMediaQuery *query; //媒体队列
@property(nonatomic)BOOL isPlayMusic;
@property(nonatomic)BOOL isPause;
@end
@implementation BTHomeViewController

#pragma mark - *********************生命周期*********************

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configuration];
    
    [self.view addSubview:self.collectionView];
    [self autoLayoutForSubView];
    
    [self.collectionView registerClass:[BTHomeContentsCell class] forCellWithReuseIdentifier:@"BTHomeContentsCell"];
    [self.collectionView registerClass:[BTHomeHeaderCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"BTHomeHeaderCell"];
    
    self.deviceName=nil;
    //    self.dataArr = [NSMutableArray arrayWithObjects:@"添加",nil];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"同步"] style:UIBarButtonItemStyleDone target:self action:@selector(tongbu)];//显示日历
   //同步
    self.kpIndicatorView = [[KPIndicatorView alloc] initWithFrame:CGRectMake(ScreenW-50,0,45, 45)];
    [self.navigationController.navigationBar addSubview: self.kpIndicatorView];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    //初始化蓝牙对象
    //初始化
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    
    //扫描
    [manager scan];
    //获取步数的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeValue:) name:@"steps" object:nil];
    //自拍
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeValue) name:@"zipai" object:nil];
    
    [self music];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(systemMusicPlayerControltest:) name:@"musicPlay" object:nil];}
#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
    CBPeripheral *peripheral = peripherals.firstObject;

    [weakManager connect:peripheral];
    
}
#pragma =========================自拍通知方法==============================================
-(void)changeValue
{
    
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    //    {
    //        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;//设置类型为相机
    //        UIImagePickerController *picker = [[UIImagePickerController alloc] init];//初始化
    //        picker.delegate = self;//设置代理
    //        picker.allowsEditing = YES;//设置照片可编辑
    //        picker.sourceType = sourceType;
    //        //设置是否显示相机控制按钮 默认为YES
    //        picker.showsCameraControls = YES;
    //
    //        //        //创建叠加层(例如添加的相框)
    //        //        UIView *overLayView=[[UIView alloc]initWithFrame:CGRectMake(0, 120, 320, 254)];
    //        //        //取景器的背景图片，该图片中间挖掉了一块变成透明，用来显示摄像头获取的图片；
    //        //        UIImage *overLayImag=[UIImage imageNamed:@"zhaoxiangdingwei.png"];
    //        //        UIImageView *bgImageView=[[UIImageView alloc]initWithImage:overLayImag];
    //        //        [overLayView addSubview:bgImageView];
    //        //        picker.cameraOverlayView=overLayView;
    //
    //        //选择前置摄像头或后置摄像头
    //        picker.cameraDevice=UIImagePickerControllerCameraDeviceFront;
    //        [self presentViewController:picker animated:YES completion:^{
    //        }];
    //    }
    //    else {
    //        NSLog(@"该设备无相机");
    //    }
    
    XYHUIImagePickerController *vc = [[XYHUIImagePickerController alloc]init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma =====================音乐播放=====================================
- (void)music{
    NSLog(@"systemVersion==%f",[[UIDevice currentDevice] systemVersion].floatValue);
    if ([[UIDevice currentDevice] systemVersion].floatValue >= 8.0) {
        self.musicPlayerController =  [MPMusicPlayerController applicationMusicPlayer];//初始化系统音乐播放器
    }else{
        self.musicPlayerController =  [MPMusicPlayerController applicationMusicPlayer];
        
    }
    self.musicPlaybackState = self.musicPlayerController.playbackState;
    if (![self isPlayingItem]  ) {
        [self getMusicListFromMusicLibrary];
    }
    self.isPlayMusic = YES;
}
// 判断有没有正在播放的媒体项目
- (BOOL)isPlayingItem {
    if ([self.musicPlayerController indexOfNowPlayingItem] == NSNotFound) {
        return NO;
    } else {
        return YES;
    }
}
//创建媒体队列
- (void)createMediaQuery {
    self.query = [MPMediaQuery songsQuery];
    [self.musicPlayerController setQueueWithQuery:self.query];
}
- (MPMediaItemCollection *)getMusicListFromMusicLibrary {
    self.query = [MPMediaQuery songsQuery];
    // 申明一个Collection便于下面给MusicPlayer赋值
    MPMediaItemCollection *mediaItemCollection;
    if (self.query.items.count == 0) {
        return 0;
    } else {
        //获取本地音乐库文件
        NSMutableArray *musicArray= [NSMutableArray array];
        for(MPMediaItem *item in self.query.items) {
            [musicArray addObject:item];
            NSLog(@"%@",item.title);
        }
        // 将音乐信息赋值给musicPlayer
        mediaItemCollection = [[MPMediaItemCollection alloc] initWithItems:[musicArray copy]];
        [self.musicPlayerController setQueueWithItemCollection:mediaItemCollection];
    }
    
    return mediaItemCollection;
}
//暂停或者播放音乐的代码实现：
- (void)musicPlay{
    [self music];
    NSLog(@"%lu",(unsigned long)self.musicPlayerController.indexOfNowPlayingItem);
    if (self.musicPlaybackState == MPMusicPlaybackStatePlaying) {
        [self.musicPlayerController pause];//暂停
        self.musicPlaybackState = MPMusicPlaybackStatePaused;
        
    }else if (self.musicPlaybackState == MPMusicPlaybackStateStopped || self.musicPlaybackState == MPMusicPlaybackStatePaused || self.musicPlaybackState == MPMusicPlaybackStateInterrupted) {
        [self.musicPlayerController play]; //播放
        self.musicPlaybackState = MPMusicPlaybackStatePlaying;
        
    }
    
}
//实现上一曲的代码：
- (void)musicBack{
    
    if (self.musicPlaybackState != MPMusicPlaybackStatePlaying) {
        [self music];
    }
    [self.musicPlayerController play];
    [self.musicPlayerController skipToPreviousItem];
    self.musicPlaybackState = MPMusicPlaybackStatePlaying;
    
}
//实现下一曲的代码：
- (void)musicNext{
    
    if (self.musicPlaybackState != MPMusicPlaybackStatePlaying) {
        [self music];
    }
    
    [self.musicPlayerController play];
    self.isPause = NO;
    [self.musicPlayerController skipToNextItem];
    self.musicPlaybackState = MPMusicPlaybackStatePlaying;
    
}
- (void)systemMusicPlayerControltest:(NSNotification *)notification {
    
    //音乐播放 <f60102> 上一首  <f60103>下一首  <f60101>暂停与播放
    NSData *data = notification.object;  //蓝牙设备传来的控制信息
    Byte *bytes = (Byte *)[data bytes];
    self.musicPlaybackState = self.musicPlayerController.playbackState;
    if (bytes[1] == 0x01) {  //验证
        if (![self isPlayingItem]) {
            [self createMediaQuery];  //若没有正在播放的媒体项目，则创建媒体队列
        }
        if (bytes[2] == 0x01) { // 播放/停止
            
            if (self.musicPlaybackState == MPMusicPlaybackStatePlaying) {
                [self  musicPlay]; //播放
                NSLog(@"暂停Music Control Error Data!");
            }
            if (self.musicPlaybackState == MPMusicPlaybackStateStopped || self.musicPlaybackState == MPMusicPlaybackStatePaused || self.musicPlaybackState == MPMusicPlaybackStateInterrupted) {
                [self  musicPlay]; //播放
                NSLog(@"播放Music Control Error Data!");
            }
        } else if (bytes[2] == 0x02) { // 切换上一曲
            [self  musicBack]; //播放
            NSLog(@"切换上一曲Music Control Error Data!");
        } else if (bytes[2] == 0x03) { // 切换下一曲
            [self  musicNext]; //播放
            NSLog(@"切换下一曲Music Control Error Data!");
        } else {
            NSLog(@"Music Control Error Data!");
        }
    }
    
}
#pragma =====================音乐播放=====================================
#pragma =========================获取步数的通知方法==============================================
- (void)changeValue:(NSNotification *)noti
{
    NSLog(@"v.userInfo == %@",noti.userInfo);
    NSLog(@"v.object == %@",noti.object);
    
    [self handleStepsValue:noti.object];
}
#pragma =========================连接外部设备====================================================================
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.collectionView reloadData];
   
}
#pragma mark -蓝牙配置和操作
-(void)tongbu
{
    
        [self sendStepsData];
        self.navigationItem.rightBarButtonItem = nil;
        [self.kpIndicatorView startAnimating];
        
}
#pragma mark -蓝牙获取步数=====================================================
- (void)sendStepsData{
    NSString *uuid = @"FFF2";
//    读取步数：
    Byte byte1[4];
    byte1[0] = 0xC6;
    byte1[1] = 0x01;
    byte1[2] = 0x08;
    byte1[3] = 0x08;
    NSData *data1 = [NSData dataWithBytes:byte1 length:4];
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data1 characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
}
- (void)handleStepsValue:(NSData *)data{
    
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    Byte  byteState = byte[2];
    //获得设备基本信息
    if (command_id == 0x26 && key == 0x09)
    {
        
        
        Byte *byte = (Byte *)[data bytes];
        Byte b[] = {byte[2],byte[3],byte[4]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        NSLog(@"==========步数:%ld==========",weight);
        self.steps = weight;
        [self.kpIndicatorView stopAnimating];
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"同步"] style:UIBarButtonItemStyleDone target:self action:@selector(tongbu)];//显示日历
        [self.collectionView reloadData];
        
        
    }
}

#pragma mark - *********************基础配置*********************

- (void)configuration
{
    [self setTitle:@"首页"];
    [self hideNaviBack];
    [self resetNavBackItemTinColor:kCOLOR_white];
    
    self.titleArray = @[@"计步统计",@"睡眠情况",@"血压测量",@"实时心率"];
}

- (void)autoLayoutForSubView
{
}

#pragma mark - *********************基础方法*********************


#pragma mark - *********************代理方法*********************
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.titleArray.count;
}

//设置Cell
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    BTHomeContentsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BTHomeContentsCell" forIndexPath:indexPath];
    if(indexPath.row == 0)
    {
        cell.homeCellType = kHomeContentsCellTypeStepNumber;
    }
    else if (indexPath.row == 1)
    {
        cell.homeCellType = kHomeContentsCellTypeSleepStatus;
    }
    else if (indexPath.row == 2)
    {
        cell.homeCellType = kHomeContentsCellTypeBloodPressure;
    }
    else if (indexPath.row == 3)
    {
        cell.homeCellType = kHomeContentsCellTypeHeartRate;
    }
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader])
    {
        //从缓存中获取 Headercell
        BTHomeHeaderCell *cell = (BTHomeHeaderCell *)[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"BTHomeHeaderCell" forIndexPath:indexPath];
        [cell setBackgroundColor:kCOLOR_white];
        [cell setStepNumber:self.steps];
        return cell;
    }
    return nil;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(kUI_WIDTH, 240);
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        WalkViewController *vc = [[WalkViewController alloc]init];
        vc.steps = [NSString stringWithFormat:@"%ld",self.steps];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else if (indexPath.row == 1){
        SleepViewController *vc = [[SleepViewController alloc]init];
        vc.hidesBottomBarWhenPushed = YES;
         [self.navigationController pushViewController:vc animated:YES];
        
    }else if (indexPath.row == 2){
        BloodPressureViewController *vc = [[BloodPressureViewController alloc]init];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else{
        HeartRateViewController *vc = [[HeartRateViewController alloc]init];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }
}

#pragma mark - *********************懒加载*********************

- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        
        CGFloat itemH = (kUI_WIDTH - kCollectionCellPadding*3) / 2;
        
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        [layout setItemSize:CGSizeMake(itemH, itemH)];
        [layout setSectionInset:UIEdgeInsetsMake(kCollectionCellPadding, kCollectionCellPadding, 0, kCollectionCellPadding)];
        [layout setMinimumLineSpacing:kCollectionCellPadding];
        [_collectionView setCollectionViewLayout:layout];
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kUI_WIDTH, kUI_HEIGHT - 49 - 10) collectionViewLayout:layout];
        [_collectionView setBackgroundColor:kCOLOR_tableView];
        [_collectionView setDelegate:self];
        [_collectionView setDataSource:self];
        [_collectionView setShowsVerticalScrollIndicator:NO];
        [_collectionView setShowsVerticalScrollIndicator:NO];
    }
    return _collectionView;
}

#pragma mark - *********************网络模型*********************

@end
