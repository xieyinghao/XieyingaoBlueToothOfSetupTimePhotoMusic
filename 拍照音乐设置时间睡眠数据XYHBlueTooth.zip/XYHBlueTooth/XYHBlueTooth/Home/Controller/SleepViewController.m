//
//  SleepViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "SleepViewController.h"
#import "WSLineChartView.h"
#import "BlueToothManager.h"
@interface SleepViewController ()
@property(nonatomic,strong)NSMutableArray *DataArr;
@property (nonatomic,strong) NSMutableData *data;
@end

@implementation SleepViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _data = [NSMutableData data];
   self.DataArr = [NSMutableArray array];
    self.title = @"睡眠记录";
    self.view.backgroundColor = [UIColor whiteColor];
    
    NSMutableArray *xArray = [NSMutableArray array];
    NSMutableArray *yArray = [NSMutableArray array];
    for (NSInteger i = 0; i < 50; i++) {
        
        [xArray addObject:[NSString stringWithFormat:@"%.1f",3+0.1*i]];
        [yArray addObject:[NSString stringWithFormat:@"%.2lf",20.0+arc4random_uniform(10)]];
        
    }
    
    
    WSLineChartView *wsLine = [[WSLineChartView alloc]initWithFrame:CGRectMake(0,0, self.view.frame.size.width, ScreenH-200) xTitleArray:xArray yValueArray:yArray yMax:24 yMin:0];
    wsLine.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:wsLine];
    
    
    //初始化
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    
    //扫描
    [manager scan];

    

}

#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
    CBPeripheral *peripheral = peripherals.firstObject;
    //过滤外设，当前缀为SMART的外设才进行连接
    //    if ([peripheral.name hasPrefix:@"SMART"]) {
    //
    //        //连接外部设备
    //        [weakManager connect:peripheral];
    //        NSLog(@"连接成功");
    //    }
    [weakManager connect:peripheral];
    
    
}
#pragma =========================app发送获得设步数(这个不是香山协议里面的)===============================
/**
 发送数据
 */
- (void)sendStepsData
{
    NSString *uuid = @"FFF2";
    
    //睡眠
    Byte byte1[6];
    byte1[0] = 0xC4;
    byte1[1] = 0x03;
    byte1[2] = 0x04;//周4
    byte1[3] = 0x17;//23点
    byte1[4] = 0x03;//代表返回的是1个小时的间隔时间 同理02 03
    
    byte1[5] = byte1[2]^byte1[3]^byte1[4];
    NSData *data1 = [NSData dataWithBytes:byte1 length:6];
    NSLog(@"%@",data1);
    

    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data1 characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleStepsValue:value];
         
     }];
}
/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleStepsValue:(NSData *)data
{
    //长度大于70就结束，否则一直拼接
    if (self.data.length >  70) {
        
        NSLog(@"==========最终数据==========%@",self.data);
        
        
        
        Byte *byte = (Byte*)self.data.bytes;
        //第一个数据
        Byte by6 = byte[6];
        Byte by7 = byte[7];
        NSInteger sleep6 = by6&0xf0;
        sleep6 /=16;
        NSLog(@"======第一个sleep=%ld=========",sleep6);
        NSInteger number6 = by6&0x0f;
        NSInteger numbers6 = number6*16*16 +by7;
        NSLog(@"=====第一个number=====%ld==========",numbers6);
        NSString *str1 = [NSString stringWithFormat:@"%ld",(long)number6];
        [self.DataArr addObject:str1];
        
        
        //第2个数据
        Byte by12 = byte[12];
        Byte by13 = byte[13];
        NSInteger sleep12 = by12&0xf0;
        sleep12 /=16;
        NSLog(@"======第2个sleep=%ld=========",sleep12);
        NSInteger number12 = by12&0x0f;
        NSInteger numbers12 = number12*16*16 +by13;
        NSLog(@"=====第2个number=====%ld==========",numbers12);
        NSString *str2 = [NSString stringWithFormat:@"%ld",(long)number12];
        [self.DataArr addObject:str2];
        //第3个数据
        Byte by18 = byte[18];
        Byte by19 = byte[19];
        NSInteger sleep18 = by18&0xf0;
        sleep18 /=16;
        NSLog(@"======第3个sleep=%ld=========",sleep18);
        NSInteger number18 = by18&0x0f;
        NSInteger numbers18 = number18*16*16 +by19;
        NSLog(@"=====第3个number=====%ld==========",numbers18);
        NSString *str3 = [NSString stringWithFormat:@"%ld",(long)numbers18];
        [self.DataArr addObject:str3];
        
        //第4个数据
        Byte by24 = byte[24];
        Byte by25 = byte[25];
        NSInteger sleep24 = by24&0xf0;
        sleep24 /=16;
        NSLog(@"======第4个sleep=%ld=========",sleep24);
        NSInteger number24 = by24&0x0f;
        NSInteger numbers24 = number24*16*16 +by25;
        NSLog(@"=====第4个number=====%ld==========",numbers24);
        NSString *str4 = [NSString stringWithFormat:@"%ld",(long)numbers24];
        [self.DataArr addObject:str4];
        
        //第5个数据
        Byte by30 = byte[30];
        Byte by31 = byte[31];
        NSInteger sleep30 = by30&0xf0;
        sleep30 /=16;
        NSLog(@"======第5个sleep=%ld=========",sleep30);
        NSInteger number30 = by30&0x0f;
        NSInteger numbers30 = number30*16*16 +by31;
        NSLog(@"=====第5个number=====%ld==========",numbers30);
        NSString *str5 = [NSString stringWithFormat:@"%ld",(long)numbers30];
        [self.DataArr addObject:str5];
        //第6个数据
        Byte by36 = byte[36];
        Byte by37 = byte[37];
        NSInteger sleep36 = by36&0xf0;
        sleep36 /=16;
        NSLog(@"======第6个sleep=%ld=========",sleep36);
        NSInteger number36 = by36&0x0f;
        NSInteger numbers36 = number36*16*16 +by37;
        NSLog(@"=====第6个number=====%ld==========",numbers36);
        NSString *str6 = [NSString stringWithFormat:@"%ld",(long)numbers36];
        [self.DataArr addObject:str6];
        //第7个数据
        Byte by42 = byte[42];
        Byte by43 = byte[43];
        NSInteger sleep42 = by42&0xf0;
        sleep42 /=16;
        NSLog(@"======第7个sleep=%ld=========",sleep42);
        NSInteger number42 = by42&0x0f;
        NSInteger numbers42 = number42*16*16 +by43;
        NSLog(@"=====第7个number=====%ld==========",numbers42);
        NSString *str7 = [NSString stringWithFormat:@"%ld",(long)numbers42];
        [self.DataArr addObject:str7];
        //第8个数据
        Byte by48 = byte[48];
        Byte by49 = byte[49];
        NSInteger sleep48 = by48&0xf0;
        sleep48 /=16;
        NSLog(@"======第8个sleep=%ld=========",sleep48);
        NSInteger number48 = by48&0x0f;
        NSInteger numbers48 = number48*16*16 +by49;
        NSLog(@"=====第8个number=====%ld==========",numbers48);
        NSString *str8 = [NSString stringWithFormat:@"%ld",(long)numbers48];
        [self.DataArr addObject:str8];
        //第9个数据
        Byte by54 = byte[54];
        Byte by55 = byte[55];
        NSInteger sleep54 = by54&0xf0;
        sleep54 /=16;
        NSLog(@"======第9个sleep=%ld=========",sleep54);
        NSInteger number54 = by54&0x0f;
        NSInteger numbers54 = number54*16*16 +by55;
        NSLog(@"=====第9个number=====%ld==========",numbers54);
        NSString *str9 = [NSString stringWithFormat:@"%ld",(long)numbers54];
        [self.DataArr addObject:str9];
        //第10个数据
        Byte by60 = byte[60];
        Byte by61 = byte[61];
        NSInteger sleep = by60&0xf0;
        sleep /=16;
        NSLog(@"======第10个sleep=%ld=========",sleep);
        NSInteger number1 = by60&0x0f;
        NSInteger number = number1*16*16 +by61;
        NSLog(@"=====第10个number=====%ld==========",number);
        NSString *str10 = [NSString stringWithFormat:@"%ld",(long)number];
        [self.DataArr addObject:str10];
        
        //第11个数据
        Byte by66 = byte[66];
        Byte by67 = byte[67];
        NSInteger sleep66 = by66&0xf0;
        sleep66 /=16;
        NSLog(@"======第11个sleep=%ld=========",sleep66);
        NSInteger number66 = by66&0x0f;
        NSInteger numbers66 = number66*16*16 +by67;
        NSLog(@"=====第11个number=====%ld==========",numbers66);
        NSString *str11 = [NSString stringWithFormat:@"%ld",(long)numbers66];
        [self.DataArr addObject:str11];
        //第12个数据
        Byte by72 = byte[72];
        Byte by73 = byte[73];
        NSInteger sleep72 = by72&0xf0;
        sleep72 /=16;
        NSLog(@"======第12个sleep=%ld=========",sleep72);
        NSInteger number72 = by72&0x0f;
        NSInteger numbers72 = number72*16*16 +by73;
        NSLog(@"=====第12个number=====%ld==========",numbers72);
        NSString *str12 = [NSString stringWithFormat:@"%ld",(long)numbers72];
        [self.DataArr addObject:str12];
        
        //第12个数据
        Byte by78 = byte[78];
        Byte by79 = byte[79];
        NSInteger sleep78 = by78&0xf0;
        sleep78 /=16;
        NSLog(@"=====第13个=sleep=%ld=========",sleep78);
        NSInteger number78 = by78&0x0f;
        NSInteger numbers78 = number78*16*16 +by79;
        NSLog(@"=====第13个number=====%ld==========",numbers78);
        NSString *str13 = [NSString stringWithFormat:@"%ld",(long)numbers78];
        [self.DataArr addObject:str13];
        
      
        
    }else
    {
        
        [self.data appendData:data];
        NSLog(@"==========添加数据==========%@",self.data);
        
    }

    
}

@end
