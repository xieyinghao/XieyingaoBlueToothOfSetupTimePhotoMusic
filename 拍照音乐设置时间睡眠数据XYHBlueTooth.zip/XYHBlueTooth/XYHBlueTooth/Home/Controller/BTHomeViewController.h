//
//  HomeViewController.h
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BaseViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "BabyBluetooth.h"
@interface BTHomeViewController : BaseViewController<CBCentralManagerDelegate,CBPeripheralDelegate>



@end
