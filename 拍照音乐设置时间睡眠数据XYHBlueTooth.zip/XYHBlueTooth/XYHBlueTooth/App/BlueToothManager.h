//
//  BlueToothManager.h
//  04-蓝牙
//
//  Created by vera on 16/10/14.
//  Copyright © 2016年 deli. All rights reserved.
//

/*
 1.创建中心角色
 2.扫描外部设备
 3.连接外部设备
 4.扫描外部设备中服务和特征。
 5.发送或者接收数据
 6.蓝牙断开
 */

#import <Foundation/Foundation.h>
#import "NSData+TSExtension.h"
//导入头文件
#import <CoreBluetooth/CoreBluetooth.h>
static NSString *ServicesUUID   = @"FFF0";// heart 服务UUID
static NSString *NotifyUUID = @"FFF1";// 通知 通知UUID
static NSString *WriteUUID   = @"FFF2";//写    服务UUID

//扫描到外部设备的回调
typedef void(^BlueToothDidScanPeripheralsCallback)(NSArray *peripherals);

//收到外部设备的数据的回调
typedef void(^BlueToothDidUpdateValueCallback)(CBCharacteristic *characteristic, NSData *value);



@interface BlueToothManager : NSObject

+ (instancetype)shareManager;

//扫描到外部设置的回调
@property (nonatomic, copy) BlueToothDidScanPeripheralsCallback blueToothDidScanPeripheralsCallback;
//收到外部设备的数据的回调
@property (nonatomic, copy) BlueToothDidUpdateValueCallback blueToothDidUpdateValueCallback;

//设置扫描到外部设置的回调
- (void)setBlueToothDidScanPeripheralsCallback:(BlueToothDidScanPeripheralsCallback)blueToothDidScanPeripheralsCallback;
//设置收到外部设备的数据的回调
- (void)setBlueToothDidUpdateValueCallback:(BlueToothDidUpdateValueCallback)blueToothDidUpdateValueCallback;
//app 发送获得设备基本信息请求
- (void)sendBasicMassage:(NSInteger)version;
//扫描的UUID
@property(nonatomic,strong)NSString *UUIDString;
/**
 开始扫描
 */
- (void)scan;

// 停止扫描
-(void)stopScan;
/**
 连接外部设备

 @param peripheral <#peripheral description#>
 */
- (void)connect:(CBPeripheral *)peripheral;


/**
 发送数据

 @param data       <#data description#>
 @param uuidString <#uuidString description#>
 */
- (void)writeData:(NSData *)data characteristicUUIDString:(NSString *)uuidString type:(CBCharacteristicWriteType)type;

@end
