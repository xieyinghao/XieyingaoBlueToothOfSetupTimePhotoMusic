//
//  ChallengeViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BTChallengeViewController.h"
#import "CalculagraphView.h"
@interface BTChallengeViewController (){
    CalculagraphView *_calculagraphView;
}

@end

@implementation BTChallengeViewController

#pragma mark - *********************生命周期*********************

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configuration];
    
    [self autoLayoutForSubView];
}

#pragma mark - *********************基础配置*********************

- (void)configuration
{
    [self setTitle:@"挑战"];
    [self hideNaviBack];
    [self resetNavBackItemTinColor:kCOLOR_white];
    
//    _calculagraphView = [[CalculagraphView alloc] initWithFrame:CGRectMake(75, 300, CGRectGetWidth(self.view.bounds) - 150, 50)];
//    _calculagraphView.backgroundColor = [UIColor redColor];
//    [self.view addSubview:_calculagraphView];
//     [_calculagraphView start]; 开始
//     [_calculagraphView suspend]; 暂停
//       [_calculagraphView goOn]; 继续
//    [_calculagraphView stop];结束
    
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    
    
}
- (void)autoLayoutForSubView
{
    
}

#pragma mark - *********************基础方法*********************


#pragma mark - *********************代理方法*********************


#pragma mark - *********************响应事件*********************


#pragma mark - *********************懒加载*********************


#pragma mark - *********************网络模型*********************

@end
