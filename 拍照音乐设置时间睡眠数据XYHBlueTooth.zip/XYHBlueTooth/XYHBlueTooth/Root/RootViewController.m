//
//  ViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "RootViewController.h"
#import "BTTabBarViewController.h"
#import "AppHeader.h"
#import "AppDelegate.h"

@interface RootViewController ()

@end

@implementation RootViewController

#pragma mark - *********************生命周期*********************

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configuration];
    
    [self autoLayoutForSubView];
    
    BTTabBarViewController *tabBarCtrl = [BTTabBarViewController instanceFromStoryBoard];
    AppDelegate * app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app setRootViewController:tabBarCtrl];
}

#pragma mark - *********************基础配置*********************

- (void)configuration
{
    
}

- (void)autoLayoutForSubView
{
    
}

#pragma mark - *********************基础方法*********************


#pragma mark - *********************代理方法*********************


#pragma mark - *********************响应事件*********************


#pragma mark - *********************懒加载*********************


#pragma mark - *********************网络模型*********************

@end
